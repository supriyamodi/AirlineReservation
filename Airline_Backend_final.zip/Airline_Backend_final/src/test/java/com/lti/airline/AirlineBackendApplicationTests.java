package com.lti.airline;

import java.util.ArrayList;
import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.lti.airline.model.Admin;
import com.lti.airline.model.Booking;
import com.lti.airline.model.Cancellation;
import com.lti.airline.model.Flight;
import com.lti.airline.model.FlightCustomer;
import com.lti.airline.model.Payment;
import com.lti.airline.model.Seat;
import com.lti.airline.model.Seat.SeatKey;
import com.lti.airline.repository.BookingRepo;
import com.lti.airline.repository.FlightCustomerRepo;
import com.lti.airline.repository.FlightRepo;
import com.lti.airline.repository.PaymentRepo;
import com.lti.airline.repository.SeatRepo;
import com.lti.airline.repository.AdminRepoImpl;
import com.lti.airline.request.SeatStatusRequest;
import com.lti.airline.service.FlightService;
import com.lti.airline.service.AdminServiceImpl;

@SpringBootTest
class AirlineBackendApplicationTests {

	Time sqlTimestamp1 = Time.valueOf("18:00:00");
	Time sqlTimestamp2 = Time.valueOf("20:00:00");
	
	@Autowired
	AdminRepoImpl admRepo;
	
	@Autowired
	AdminServiceImpl admSrvcImpl;
	
	@Autowired
	SeatRepo seatRepo;

	@Autowired
	FlightRepo flightRepo;

	@Autowired
	BookingRepo bookingRepo;
	
	@Autowired
	PaymentRepo paymentRepo;

	@Autowired
	FlightCustomerRepo flightCustomerRepo;

	@Autowired
	FlightService flightService;

	@Test
	void contextLoads() {
	}

	@Test
	void loadOneSeat() {
		System.out.println("Loading one seat");
		Seat s = seatRepo.getSeat(new Seat.SeatKey("1A", 501));
	}

	@Test
	void loadAllSeatsTest() {
		System.out.println("Loading all the seats...");
		List<Seat> seatList = seatRepo.getAllSeats();
		System.out.println("seatList " + seatList.size());
		for (Seat seat : seatList) {
			System.out.println("Seat : " + seat);
		}
	}

	@Test
	void loadFlightsFromSourceToDest() {
		System.out.println("Loading flights from src tpo dest...");
		List<Long> fList = flightRepo.getFlightIdsUsingSrcAndDest("Mumbai", "Chennai");
		for (Long flight : fList) {
			System.out.println("flight id:" + flight);
		}
	}

	@Test
	void loadBookingIdsOnparticularDateForSpecificFlight() {
		System.out.println("Loading booking ids for particular date for particular flight...");
		Date date = Date.valueOf("2021-05-13");
		ArrayList<Long> bookingIds = flightRepo.getBookingIdsOnparticularDateForSpecificFlight((long) 103, date);
		for (Long bId : bookingIds) {
			System.out.println("booking id:" + bId);
		}
	}

	@Test
	void insertSeatTest() {
		System.out.println("Inserting seat..");
		Seat.SeatKey skey = new Seat.SeatKey("3D", 510);
		Seat seat = new Seat(skey, "Booked");
		boolean status = seatRepo.insertSeat(seat);
		System.out.println(status);
	}

	@Test
	void getSeatCountForEachBookingIdTest() {
		System.out.println("Getting seatCount for particular booking..");
		long count = flightRepo.getSeatCountForEachBookingId("6D", (long) 510);
		System.out.println("Seat count: " + count);
	}

	@Test
	void loadgetFlightDetailsByFlightIdTest() {
		System.out.println("Getting flight details...");
		Flight flight = flightRepo.getFlightDetailsByFlightId((long) 102);
		System.out.println("Flight Details: " + flight.getFlightId());
	}

	@Test
	void getBookingTest() {
		System.out.println("Getting booking details...");
		Booking booking = bookingRepo.getBooking(501);
		System.err.println("Booking details:" + booking.getBookingId());
	}

	@Test
	void getUserDetailsTest() {
		System.out.println("Getting user details...");
		FlightCustomer user = flightCustomerRepo.getUserDetails(1);
		System.err.println("user details:" + user.getFirstName());
	}

	@Test
	void createBookingtest() {
		long flightId = 103;
		Flight flight = flightRepo.getFlightDetailsByFlightId(flightId);
		Time arrivalTime = flight.getArrivalTime();
		Time departureTime = flight.getDepartureTime();
//		Date duration= (Date)(arrivalTime-departureTime);
		long userId = 1;
		FlightCustomer user = flightCustomerRepo.getUserDetails(userId);

		Booking booking = new Booking();
		Date date = Date.valueOf(LocalDate.now());
		booking.setBookingDate(date);
		booking.setTravelStartDate(date);
		booking.setFlight(flight);
		booking.setClassType("Economy");
		booking.setJourneyType("One_Way");
		booking.setNoOfSeatsBookedByUser(2);
		booking.setFlightCustomer(user);
		booking.setBookingStatus("Payment_Failed");
		long bookingId = bookingRepo.createBooking(booking);

		System.out.println("Booking Id :" + bookingId);
	}

	@Test
	void getBookingIdsForFlightOnTravelDateTest() {
		System.out.println("Getting seat status ....");
		Date date = Date.valueOf("2021-05-13");
		SeatStatusRequest request = new SeatStatusRequest((long) 103, date);
		List<Long> bookingIds = bookingRepo.getBookingIdsForFlightOnTravelDate(request);
		for (Long long1 : bookingIds) {
			System.out.println("BookingId: " + long1);
		}
	}

	@Test
	void getBookedSeatStatustest() {
		System.out.println("Getting booked seat status ....");
		Seat.SeatKey skey = new Seat.SeatKey("1A",501);
		boolean status = seatRepo.getBookedSeatStatus(skey);
		System.out.println(status);
	}

	@Test
	void insertPaymentTest() {
		Payment payment = new Payment();

		Booking booking = bookingRepo.getBooking(96);

		payment.setAmount(5000);
		payment.setBooking(booking);
		payment.setPaymentMethod("Card");
		payment.setPaymentStatus("Payment_Failed");

		boolean status = paymentRepo.insertPayment(payment);
		System.out.println(status);
	}
	
	@Test
	void updateSeatStatusTest() {
		System.out.println("Updating Seat Status ....");
		Seat.SeatKey skey = new Seat.SeatKey("3D", 502);
		seatRepo.updateSeatStatus(skey,"Booked");
		
	}
	
	@Test
	void updateBookingStatusTest() {
		System.out.println("Updating Booking Status ....");
		bookingRepo.updateBookingStatus(508, "Confirmed");
	}
	
	@Test
	void getSeatByBookingIdTest() {
		System.out.println("getting seat keys...");
		List<Seat.SeatKey> sList = seatRepo.getSeatByBookingId(501);
		for (Seat.SeatKey seatKey : sList) {
			System.out.println(seatKey);
		}
	}
	
	@Test
	void getSuccessfulPaymentByBookingIdTest() {
		System.out.println("getting payment details...");
		Payment payment = paymentRepo.getSuccessfulPaymentByBookingId(503);
		System.out.println("pId:"+payment.getPaymentId());
	}
	
	@Test
	void insertIntoCancellationTest() {
		System.out.println("Inserting into cancellation...");
		Payment payment = paymentRepo.getSuccessfulPaymentByBookingId(503);
		double refundAmount = 0.9 * payment.getAmount();
		Cancellation cancel = new Cancellation();
		Date date = Date.valueOf(LocalDate.now());
		cancel.setCancellationDate(date);
		cancel.setPayment(payment);
		cancel.setRefundStatus("Refunded");
		cancel.setRefundAmount(refundAmount);
		boolean status = paymentRepo.insertIntoCancellation(cancel);
	}
	
	@Test
	void getUserDetails() {
		System.out.println("Getting user details...");
		FlightCustomer flightcust= flightCustomerRepo.getUserDetails(1);
		System.out.println(" User details: "+flightcust.getEmailId()+flightcust.getFirstName());		
	}
	// ---------------------Service Layer Testing------------------
//	@Test
//	void getAvailableFlightsServiceTest() {
//		System.out.println("Getting Valid flight details");
//		List<Flight> validFlights = flightService.getAvailableFlightsService();
//		for (Flight flight : validFlights) {
//			System.out.println("Flight Id:"+flight.getFlightId());
//		}
//	}
//	
	
	
	@Test
	void loginAdmin() {
		System.out.println("Admin Login");
		Admin admin = new Admin("admin@gmail.com", "Admin");
		admRepo.loginAdmin(admin);
		System.out.println("Admin Login Repository Testing Successful");
		
	}

	@Test
	void addFlightTest() {
		System.out.println("Adding Flight");
		
		Flight f1 = new Flight(sqlTimestamp2, sqlTimestamp1, "Goa", "T1", 7000, "Rise&Fly", "Active", "Indore","T2", 60);
		admRepo.addFlight(f1);
		System.out.println("Admin Flight Repository Add-Testing Successful");
	}

	@Test
	void deleteFlightTest() {
		System.out.println("Delete Flight");
		admRepo.deleteFlight((long) 101);
		System.out.println("Admin Flight Repository Delete-Testing Successful");
	}
	
	@Test
	void loginAdminServiceTest() {
		System.out.println("Admin Login Service Testing");
		Admin admin = new Admin("admin@gmail.com", "Admin");
		admSrvcImpl.loginAdminService(admin);
		System.out.println("Admin Login Service Testing Successful");
		
	}
	
	@Test
	void addFlightServiceTest() {
		System.out.println("Adding Flight Service Testing");
		
		Flight f1 = new Flight(sqlTimestamp2, sqlTimestamp1, "Indore", "T1", 7000, "Rise&Fly", "Active", "Patna","T2", 60);
		admSrvcImpl.addFlightService(f1);
		System.out.println("Admin Flight Repository Service Add-Testing Successful");
	}

	@Test
	void deleteFlightServiceTest() {
		System.out.println("Delete Flight Service Testing");
		admSrvcImpl.deleteFlightService((long) 102);
		System.out.println("Admin Flight Repository Delete-Testing Successful");
	}

}
