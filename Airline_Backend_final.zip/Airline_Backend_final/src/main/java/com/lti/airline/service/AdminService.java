package com.lti.airline.service;

import org.springframework.stereotype.Service;

import com.lti.airline.model.Admin;
import com.lti.airline.model.Flight;

@Service
public interface AdminService {
	
	public boolean loginAdminService(Admin admin);
	void addFlightService(Flight newFlight);
	void deleteFlightService(long flightId);

}
