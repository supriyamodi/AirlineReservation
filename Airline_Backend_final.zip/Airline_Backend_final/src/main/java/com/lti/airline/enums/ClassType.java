package com.lti.airline.enums;

public enum ClassType {
	
	Business,
	Economy

}
