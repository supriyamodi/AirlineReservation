package com.lti.airline.model;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import java.util.Set;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the BOOKING database table.
 * 
 */
@Entity
@Table(name= "BOOKING")
@NamedQuery(name="Booking.findAll", query="SELECT b FROM Booking b")
public class Booking implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="BOOKING_ID")
	private long bookingId;

	@Column(name="BOOKING_DATE")
	private Date bookingDate;

	@Column(name="BOOKING_STATUS")
	private String bookingStatus;

	@Column(name="CLASS_TYPE")
	private String classType;

	@Column(name="JOURNEY_TYPE")
	private String journeyType;

	@Column(name="NO_OF_SEATS_BOOKED_BY_USER")
	private int noOfSeatsBookedByUser;

//	@Temporal(TemporalType.DATE)
	@Column(name="TRAVEL_END_DATE")
	private Date travelEndDate;

//	@Temporal(TemporalType.DATE)
	@Column(name="TRAVEL_START_DATE")
	private Date travelStartDate;

	//bi-directional many-to-one association to Booking
	@ManyToOne
	@JoinColumn(name="PARENT_BOOKING_ID")
	private Booking booking;

	//bi-directional many-to-one association to Booking
	@OneToMany(mappedBy="booking", fetch=FetchType.LAZY)
	private Set<Booking> bookings;

	//bi-directional many-to-one association to Flight
	@ManyToOne
	@JoinColumn(name="FLIGHT_ID")
	private Flight flight;

	//bi-directional many-to-one association to FlightCustomer
	@ManyToOne
	@JoinColumn(name="USER_ID")
	private FlightCustomer flightCustomer;

	//bi-directional many-to-one association to Payment
	@OneToMany(mappedBy="booking", fetch=FetchType.LAZY)
	private Set<Payment> payments;

//	//bi-directional many-to-one association to Seat
//	@OneToMany(mappedBy="booking", fetch=FetchType.LAZY)
//	private Set<Seat> seats;

	public Booking() {
	}

	public long getBookingId() {
		return this.bookingId;
	}

	public void setBookingId(long bookingId) {
		this.bookingId = bookingId;
	}

	

	public Date getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}

	public String getBookingStatus() {
		return this.bookingStatus;
	}

	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	public String getClassType() {
		return this.classType;
	}

	public void setClassType(String classType) {
		this.classType = classType;
	}

	public String getJourneyType() {
		return this.journeyType;
	}

	public void setJourneyType(String journeyType) {
		this.journeyType = journeyType;
	}

	public int getNoOfSeatsBookedByUser() {
		return this.noOfSeatsBookedByUser;
	}

	public void setNoOfSeatsBookedByUser(int noOfSeatsBookedByUser) {
		this.noOfSeatsBookedByUser = noOfSeatsBookedByUser;
	}

	public Date getTravelEndDate() {
		return this.travelEndDate;
	}

	public void setTravelEndDate(Date travelEndDate) {
		this.travelEndDate = travelEndDate;
	}

	public Date getTravelStartDate() {
		return this.travelStartDate;
	}

	public void setTravelStartDate(Date travelStartDate) {
		this.travelStartDate = travelStartDate;
	}

	@JsonIgnore
	public Booking getBooking() {
		return this.booking;
	}

	public void setBooking(Booking booking) {
		this.booking = booking;
	}

	@JsonIgnore
	public Set<Booking> getBookings() {
		return this.bookings;
	}

	public void setBookings(Set<Booking> bookings) {
		this.bookings = bookings;
	}

	public Booking addBooking(Booking booking) {
		getBookings().add(booking);
		booking.setBooking(this);

		return booking;
	}

	public Booking removeBooking(Booking booking) {
		getBookings().remove(booking);
		booking.setBooking(null);

		return booking;
	}

	@JsonIgnore
	public Flight getFlight() {
		return this.flight;
	}

	public void setFlight(Flight flight) {
		this.flight = flight;
	}

	@JsonIgnore
	public FlightCustomer getFlightCustomer() {
		return this.flightCustomer;
	}

	public void setFlightCustomer(FlightCustomer flightCustomer) {
		this.flightCustomer = flightCustomer;
	}

	@JsonIgnore
	public Set<Payment> getPayments() {
		return this.payments;
	}

	public void setPayments(Set<Payment> payments) {
		this.payments = payments;
	}

	public Payment addPayment(Payment payment) {
		getPayments().add(payment);
		payment.setBooking(this);

		return payment;
	}

	public Payment removePayment(Payment payment) {
		getPayments().remove(payment);
		payment.setBooking(null);

		return payment;
	}

//	@JsonIgnore
//	public Set<Seat> getSeats() {
//		return this.seats;
//	}
//
//	public void setSeats(Set<Seat> seats) {
//		this.seats = seats;
//	}
//
//	public Seat addSeat(Seat seat) {
//		getSeats().add(seat);
//		seat.setBooking(this);
//
//		return seat;
//	}
//
//	public Seat removeSeat(Seat seat) {
//		getSeats().remove(seat);
//		seat.setBooking(null);
//		return seat;
//	}

}