package com.lti.airline.model;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the SEAT database table.
 * 
 */
@Entity
@NamedQuery(name="Seat.findAll", query="SELECT s FROM Seat s")
@Table(name="SEAT")
public class Seat implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SeatKey seatKey;
	
	@Column(name="SEAT_STATUS")
	private String seatStatus;

	//bi-directional many-to-one association to Booking
//	@ManyToOne
//	@JoinColumn(name="BOOKING_ID")
//	private Booking booking;

	//bi-directional many-to-one association to Passenger
//	@ManyToOne
//	@JoinColumn(name="PASSENGER_ID")
//	private Passenger passenger;

	public Seat() {
		super();
	}
	

	public Seat(SeatKey seatKey, String seatStatus) {
		super();
		this.seatKey = seatKey;
		this.seatStatus = seatStatus;
	}


	@Embeddable
	public static class SeatKey implements Serializable{
		
		String seatNo;
		long bookingId;
		public SeatKey() {
			super();
			// TODO Auto-generated constructor stub
		}
		public SeatKey(String seatNo,long bookingId) {
			super();
			this.bookingId = bookingId;
			this.seatNo = seatNo;
		}
		@Override
		public int hashCode() {
			return Objects.hash(bookingId, seatNo);
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			SeatKey other = (SeatKey) obj;
			return bookingId == other.bookingId && Objects.equals(seatNo, other.seatNo);
		}
		public long getBookingId() {
			return bookingId;
		}
		public void setBookingId(long bookingId) {
			this.bookingId = bookingId;
		}
		public String getSeatNo() {
			return seatNo;
		}
		public void setSeatNo(String seatNo) {
			this.seatNo = seatNo;
		}
		@Override
		public String toString() {
			return "SeatKey [bookingId=" + bookingId + ", seatNo=" + seatNo + "]";
		}
		
		
	}
	
	

	public String getSeatStatus() {
		return this.seatStatus;
	}

	public void setSeatStatus(String seatStatus) {
		this.seatStatus = seatStatus;
	}

	@Override
	public String toString() {
		return "Seat [seatKey=" + seatKey + ", seatStatus=" + seatStatus + "]";
	}
	
	

//	@JsonIgnore
//	public Booking getBooking() {
//		return this.booking;
//	}
//
//	public void setBooking(Booking booking) {
//		this.booking = booking;
//	}
//
//	@JsonIgnore
//	public Passenger getPassenger() {
//		return this.passenger;
//	}
//
//	public void setPassenger(Passenger passenger) {
//		this.passenger = passenger;
//	}

}