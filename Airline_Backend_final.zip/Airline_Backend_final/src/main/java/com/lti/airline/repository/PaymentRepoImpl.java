package com.lti.airline.repository;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lti.airline.model.Cancellation;
import com.lti.airline.model.Payment;


@Repository
public class PaymentRepoImpl extends BaseRepo implements PaymentRepo{

	@Transactional
	public boolean insertPayment(Payment payment) {
		entityManager.persist(payment);
		if(payment.getPaymentStatus().equals("Successful")) {
			return true;
		}
		else
			return false;
	}

	@Transactional
	public Payment getSuccessfulPaymentByBookingId(long bookingId) {
		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery(
				"select p from Payment p where p.booking.bookingId=:bId and p.paymentStatus=:status");
		query.setParameter("bId", bookingId);
		query.setParameter("status", "Successful");
		Payment payment = (Payment) query.getSingleResult();
		return payment;
	}

	@Transactional
	public boolean insertIntoCancellation(Cancellation cancel) {
		entityManager.persist(cancel);
		return true;
	}

	
}
