package com.lti.airline.service;

import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.lti.airline.model.Booking;
import com.lti.airline.request.SelectSeatRequest;
import com.lti.airline.response.BookingResponse;

@Service
public interface BookingService {

	Set<Booking> getAllBookingService();

	Booking getBookingService(long bookingId);

	boolean cancelBookingService(long bookingId);
	
	List<BookingResponse> getUserBookingService(long userId);
}
