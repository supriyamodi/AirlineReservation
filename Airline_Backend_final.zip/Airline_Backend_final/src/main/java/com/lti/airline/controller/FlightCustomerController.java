package com.lti.airline.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.lti.airline.model.FlightCustomer;
import com.lti.airline.service.FlightCustomerService;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/registration")
public class FlightCustomerController {

	@Autowired
	private FlightCustomerService flightCustomerService;

//	   @GetMapping(value="/userLogin", produces = MediaType.APPLICATION_JSON_VALUE)
//    public List<FlightCustomer> getAll(@RequestBody ) {
//        List<FlightCustomer> flightCustomerList=new ArrayList<FlightCustomer>();
//        
//		   flightCustomerList=flightCustomerService.getAllFlightCustomer(loginRequest);
//    return flightCustomerList;
//	   }
//	http://localhost:8090/registration/registerUser
//	@PostMapping
//	@ResponseBody
	@RequestMapping(value = "/userRegister", produces = MediaType.APPLICATION_JSON_VALUE)
	public long registerFlightCustomer(@RequestBody FlightCustomer cus) {
		System.out.println("cont..call");
		return flightCustomerService.registerFlightCustomer(cus);
	}

	@PostMapping(value = "/userLogin", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public long loginFlightCustomer(@RequestBody FlightCustomer logcus) {
		return flightCustomerService.loginFlightCustomer(logcus);
	}

	@GetMapping(value ="/userDetails/{userId}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public FlightCustomer userDetails(@PathVariable long userId) {
		FlightCustomer flightCustomer = flightCustomerService.getUserDetailsService(userId);
		return flightCustomer;
	}
}