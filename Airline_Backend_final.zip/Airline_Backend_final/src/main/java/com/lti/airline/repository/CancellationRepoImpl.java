package com.lti.airline.repository;

public class CancellationRepoImpl implements CancellationRepo{

}
