package com.lti.airline.service;

import com.lti.airline.request.PaymentRequest;

public interface PaymentService {

	boolean insertPaymentService(PaymentRequest request);

}
