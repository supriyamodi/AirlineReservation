package com.lti.airline.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lti.airline.model.Seat;
import com.lti.airline.request.SeatStatusRequest;
import com.lti.airline.request.SelectSeatRequest;

@Service
public interface SeatService {

	boolean selectSeatService(SelectSeatRequest request);

	List<Seat.SeatKey> getSeatStatusService(SeatStatusRequest request);

}
