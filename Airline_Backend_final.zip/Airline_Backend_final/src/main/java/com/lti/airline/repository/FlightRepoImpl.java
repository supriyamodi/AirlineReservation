package com.lti.airline.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lti.airline.model.Flight;
import com.lti.airline.model.FlightCustomer;
import com.lti.airline.model.Seat;

@Repository
public class FlightRepoImpl extends BaseRepo implements FlightRepo {

	

	@Transactional
	public List<Flight> getAllFlight() {
//		System.out.println("into getAllFlights..");
		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery("select f from Flight f");
		
		System.out.println(query.getResultList());
		List<Flight> fList = query.getResultList();
		for(Flight f: fList) {
			System.out.println(f);
		}
		return fList;
	}

	@Override
	public int getBookingId(Date date) {
		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery("select b.bookingId from Booking b  where bookingdate=:date");
		query.setParameter("date", date);
		int id=(int) query.getSingleResult();
		return id;
	}

	@Override
	public List<Long> getFlightIdsUsingSrcAndDest(String source, String dest) {
		EntityManager entityManager = getEntityManager();
		String status="Active";
		Query query = entityManager.createQuery("select f.flightId from Flight f where f.source=:source and f.destination=:dest and f.flightStatus=:status");
		query.setParameter("source", source);
		query.setParameter("dest", dest);
		query.setParameter("status",status);
		List<Long> flightIds = new ArrayList<Long>();
		flightIds = query.getResultList();
		
		return flightIds;
	}

	@Override
	public ArrayList<Long> getBookingIdsOnparticularDateForSpecificFlight(Long flightId, Date date) {
		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery("select b.bookingId from Booking b where b.travelStartDate=:date and b.flight.flightId=:flightId");
		query.setParameter("date", date);
		query.setParameter("flightId", (long)flightId);
		List<Long> flightIds = new ArrayList<Long>();
		flightIds = query.getResultList();
		return (ArrayList<Long>) flightIds;
	}

	@Transactional
	public long getSeatCountForEachBookingId(String seatNo, Long bId) {
		EntityManager entityManager = getEntityManager();
		Seat.SeatKey skey= new Seat.SeatKey(seatNo,bId);
		String status = "Booked";
		Query query = entityManager.createQuery("select count(s) from Seat s where s.seatKey =: skey and s.seatStatus=:status");
		query.setParameter("skey", skey);
		query.setParameter("status", status);
		long seatCount=(long) query.getSingleResult();
		return seatCount;
	}

	@Transactional
	public Flight getFlightDetailsByFlightId(Long fId) {
		EntityManager entityManager = getEntityManager();
		return entityManager.find(Flight.class, fId);
	}
	
	@Transactional
	public FlightCustomer getUserDetails(long userId) {
		
		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery("select f from FlightCustomer f where f.userId =:userId");
		query.setParameter("userId",userId);
		FlightCustomer user = (FlightCustomer) query.getSingleResult();
		return user;
	}
	
	@Transactional
	public Flight getFlightByBookingId(long bookingId) {
		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery("select b.flight.flightId from Booking b where b.bookingId=:bid");
		query.setParameter("bid", bookingId);
		long flightId=(long) query.getSingleResult();
		Flight flight= getFlightDetailsByFlightId(flightId);
		return flight;
	}
	
}
