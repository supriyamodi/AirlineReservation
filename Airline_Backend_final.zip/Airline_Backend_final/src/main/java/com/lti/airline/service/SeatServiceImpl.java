package com.lti.airline.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.airline.model.Seat;
import com.lti.airline.model.Seat.SeatKey;
import com.lti.airline.repository.BookingRepo;
import com.lti.airline.repository.SeatRepo;
import com.lti.airline.request.SeatStatusRequest;
import com.lti.airline.request.SelectSeatRequest;

@Service
public class SeatServiceImpl implements SeatService {

	@Autowired
	SeatRepo seatRepo;
	
	@Autowired
	BookingRepo bookingRepo;
	
	@Override
	public boolean selectSeatService(SelectSeatRequest request) {
		
		Seat.SeatKey skey= new Seat.SeatKey(request.getSeatNo(), request.getBookingId());
		Seat seat = new Seat(skey, "Available");
		
		boolean status = seatRepo.insertSeat(seat);
		return status;
	}

	@Override
	public List<Seat.SeatKey> getSeatStatusService(SeatStatusRequest request) {
		
		List<Seat.SeatKey> bookedSeatList = new ArrayList<Seat.SeatKey>();
		ArrayList<String> seatList = new ArrayList<String>();

			seatList.add("1A");
			seatList.add("1B");
			seatList.add("1C");
			seatList.add("1D");
			seatList.add("1E");
			seatList.add("1F");
			
			seatList.add("2A");
			seatList.add("2B");
			seatList.add("2C");
			seatList.add("2D");
			seatList.add("2E");
			seatList.add("2F");
			
			seatList.add("3A");
			seatList.add("3B");
			seatList.add("3C");
			seatList.add("3D");
			seatList.add("3E");
			seatList.add("3F");
			
			seatList.add("4A");
			seatList.add("4B");
			seatList.add("4C");
			seatList.add("4D");
			seatList.add("4E");
			seatList.add("4F");
			
			seatList.add("5A");
			seatList.add("5B");
			seatList.add("5C");
			seatList.add("5D");
			seatList.add("5E");
			seatList.add("5F");
			
			seatList.add("6A");
			seatList.add("6B");
			seatList.add("6C");
			seatList.add("6D");
			seatList.add("6E");
			seatList.add("6F");
			
			seatList.add("7A");
			seatList.add("7B");
			seatList.add("7C");
			seatList.add("7D");
			seatList.add("7E");
			seatList.add("7F");
			
			seatList.add("8A");
			seatList.add("8B");
			seatList.add("8C");
			seatList.add("8D");
			seatList.add("8E");
			seatList.add("8F");
			
			seatList.add("9A");
			seatList.add("9B");
			seatList.add("9C");
			seatList.add("9D");
			seatList.add("9E");
			seatList.add("9F");
		
			seatList.add("10A");
			seatList.add("10B");
			seatList.add("10C");
			seatList.add("10D");
			seatList.add("10E");
			seatList.add("10F");
		
		
		List<Long> bookingIds = bookingRepo.getBookingIdsForFlightOnTravelDate(request);
		
		for (Long long1 : bookingIds) {
			System.out.println("BookingIDs:" +long1);
		}
//		
		for (Long bId : bookingIds) {
			
			for (String seatNo : seatList) {
				Seat.SeatKey skey = new Seat.SeatKey(seatNo, (long)bId);
				boolean seatStatus = seatRepo.getBookedSeatStatus(skey);
				if(seatStatus) {
					bookedSeatList.add(skey);
				}
			}
		}
		
		return bookedSeatList;
	}

}
