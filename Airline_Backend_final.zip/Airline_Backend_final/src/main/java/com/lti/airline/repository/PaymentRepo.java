package com.lti.airline.repository;

import org.springframework.stereotype.Repository;

import com.lti.airline.model.Cancellation;
import com.lti.airline.model.Payment;

@Repository
public interface PaymentRepo {

	boolean insertPayment(Payment payment);
	Payment getSuccessfulPaymentByBookingId(long bookingId);
	boolean insertIntoCancellation(Cancellation cancel);

}
