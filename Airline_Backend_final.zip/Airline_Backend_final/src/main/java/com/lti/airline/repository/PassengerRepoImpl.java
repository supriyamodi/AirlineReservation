package com.lti.airline.repository;

public class PassengerRepoImpl implements PassengerRepo{

}
