package com.lti.airline.model;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Set;


/**
 * The persistent class for the PASSENGER database table.
 * 
 */
@Entity
@NamedQuery(name="Passenger.findAll", query="SELECT p FROM Passenger p")
public class Passenger implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="PASSENGER_ID")
	private long passengerId;

	private String category;

	@Column(name="PASSENGER_AGE")
	private int passengerAge;

	@Column(name="PASSENGER_FIRST_NAME")
	private String passengerFirstName;

	@Column(name="PASSENGER_GENDER")
	private String passengerGender;

	@Column(name="PASSENGER_LAST_NAME")
	private String passengerLastName;

	//bi-directional many-to-one association to FlightCustomer
	@ManyToOne
	@JoinColumn(name="USER_ID")
	private FlightCustomer flightCustomer;

//	//bi-directional many-to-one association to Seat
//	@OneToMany(mappedBy="passenger", fetch=FetchType.EAGER)
//	private Set<Seat> seats;

	public Passenger() {
	}

	public long getPassengerId() {
		return this.passengerId;
	}

	public void setPassengerId(long passengerId) {
		this.passengerId = passengerId;
	}

	public String getCategory() {
		return this.category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getPassengerAge() {
		return this.passengerAge;
	}

	public void setPassengerAge(int passengerAge) {
		this.passengerAge = passengerAge;
	}

	public String getPassengerFirstName() {
		return this.passengerFirstName;
	}

	public void setPassengerFirstName(String passengerFirstName) {
		this.passengerFirstName = passengerFirstName;
	}

	public String getPassengerGender() {
		return this.passengerGender;
	}

	public void setPassengerGender(String passengerGender) {
		this.passengerGender = passengerGender;
	}

	public String getPassengerLastName() {
		return this.passengerLastName;
	}

	public void setPassengerLastName(String passengerLastName) {
		this.passengerLastName = passengerLastName;
	}

//	@JsonIgnore
//	public FlightCustomer getFlightCustomer() {
//		return this.flightCustomer;
//	}

	public void setFlightCustomer(FlightCustomer flightCustomer) {
		this.flightCustomer = flightCustomer;
	}

//	@JsonIgnore
//	public Set<Seat> getSeats() {
//		return this.seats;
//	}
//
//	public void setSeats(Set<Seat> seats) {
//		this.seats = seats;
//	}
//
//	public Seat addSeat(Seat seat) {
//		getSeats().add(seat);
//		seat.setPassenger(this);
//
//		return seat;
//	}

//	public Seat removeSeat(Seat seat) {
//		getSeats().remove(seat);
//		seat.setPassenger(null);
//
//		return seat;
//	}

}