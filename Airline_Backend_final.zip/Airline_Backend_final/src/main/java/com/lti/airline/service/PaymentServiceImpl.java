package com.lti.airline.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.airline.model.Booking;
import com.lti.airline.model.Payment;
import com.lti.airline.model.Seat;
import com.lti.airline.repository.BookingRepo;
import com.lti.airline.repository.PaymentRepo;
import com.lti.airline.repository.SeatRepo;
import com.lti.airline.request.PaymentRequest;
@Service
public class PaymentServiceImpl implements PaymentService {
	
	@Autowired
	BookingRepo bookingRepo;
	
	@Autowired
	PaymentRepo paymentRepo;
	
	@Autowired
	SeatRepo seatRepo;

	@Override
	public boolean insertPaymentService(PaymentRequest request) {
		
		Payment payment = new Payment();
		
		Booking booking = bookingRepo.getBooking(request.getBookingId());
		
		payment.setAmount(request.getAmount());
		payment.setBooking(booking);
		payment.setPaymentMethod(request.getPaymentMethod());
		payment.setPaymentStatus(request.getPaymentStatus());
		
		
		boolean paymentStatus = paymentRepo.insertPayment(payment);
		
		
//		updateSeatStatusFrom Available to booked
		
		if(paymentStatus) {
			List<Seat.SeatKey> sKeyList = seatRepo.getSeatByBookingId(request.getBookingId());
			for (Seat.SeatKey seatKey : sKeyList) {
				System.out.println(seatKey);
			}
			for(Seat.SeatKey skey: sKeyList) {
				seatRepo.updateSeatStatus(skey,"Booked");
			}
			
			bookingRepo.updateBookingStatus(request.getBookingId(), "Confirmed");	
		}
		return paymentStatus;
	}

}
