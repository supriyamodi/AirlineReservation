package com.lti.airline.repository;

public interface PassengerRepo {

}
