package com.lti.airline.repository;

import java.sql.Date;
import java.sql.Time;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.airline.model.Booking;
import com.lti.airline.model.Flight;
import com.lti.airline.request.SeatStatusRequest;
import com.lti.airline.request.SelectFlightRequest;

@Repository
public class BookingRepoImpl extends BaseRepo implements BookingRepo{
	
	@Autowired
	FlightRepo flightRepo;
	

	@Transactional
	public long createBooking(Booking booking) {
		EntityManager entityManager = getEntityManager();
		long bookingId =  entityManager.merge(booking).getBookingId();
//		entityManager.persist(booking);
//		System.out.println("booking created..");
//		Query query = entityManager.createQuery("select b.bookingId from Booking b where b.bookingDate =:date ");
//		Date date = booking.getBookingDate();
//		query.setParameter("date", date);
//		
//		long bookingId = (long) query.getSingleResult();
		
		return bookingId;
	}


	@Transactional
	public Booking getBooking(long bookingId) {
		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery("select b from Booking b where b.bookingId =: bId");
		query.setParameter("bId", bookingId);
		Booking booking = (Booking) query.getSingleResult();
		return booking;
	}


//	@Transactional
//	public List<Long> getBookingIdsForFlightOnTravelDate(SeatStatusRequest request) {
//		
//		EntityManager entityManager = getEntityManager();
//		Query query = entityManager.createQuery("select b.bookingId from Booking b where b.flight.flightId=:fId and b.travelStartDate=:date");
//		query.setParameter("fId", request.getFlightId());
//		query.setParameter("date", request.getTravelDate());
//		List<Long> bookingIds = query.getResultList();
//		return bookingIds;
//	}
	
	@Transactional
	public List<Long> getBookingIdsForFlightOnTravelDate(SeatStatusRequest request) {
		System.out.println("Inside repo Flight Id: " + request.getFlightId() + "  Travel Date " + request.getTravelDate());
		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery(
				"select b.bookingId from Booking b where b.flight.flightId=:fId and b.travelStartDate=:date");
		query.setParameter("fId", (long) request.getFlightId());
		query.setParameter("date", Date.valueOf(request.getTravelDate().toString()));
		List<Long> bookingIds = query.getResultList();
		for (Long b : bookingIds) {
			System.out.println(b);
		}
		return bookingIds;
	}


	@Transactional
	public void updateBookingStatus(long bookingId, String status) {
		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery("UPDATE Booking b SET b.bookingStatus=:status where b.bookingId =:bId");
		query.setParameter("status", status);
		query.setParameter("bId", bookingId);
		query.executeUpdate();
		int rows = query.executeUpdate();
		System.out.println(rows+" updated");
		
	}
	
	@Override
	public List<Booking> getBookingByUserId(long userId) {
		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery("select b from Booking b where b.flightCustomer.userId=:uid");
		query.setParameter("uid", userId);
		List<Booking> bookings = query.getResultList();
		return bookings;
	}


}
