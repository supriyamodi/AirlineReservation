package com.lti.airline.response;

import java.sql.Date;

public class BookingResponse {

	private long BookingId;
	private String source;
	private String destination;
	private String journeyType;
	private int noOfPassengers;
	private double amount;
	private Date travelStartDate;
	private String bookingStatus;
	
	
	public BookingResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public BookingResponse(long bookingId, String source, String destination, String journeyType, int noOfPassengers,
			double amount, Date travelStartDate, String bookingStatus) {
		super();
		BookingId = bookingId;
		this.source = source;
		this.destination = destination;
		this.journeyType = journeyType;
		this.noOfPassengers = noOfPassengers;
		this.amount = amount;
		this.travelStartDate = travelStartDate;
		this.bookingStatus = bookingStatus;
	}


	public long getBookingId() {
		return BookingId;
	}
	public void setBookingId(long bookingId) {
		BookingId = bookingId;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getJourneyType() {
		return journeyType;
	}
	public void setJourneyType(String journeyType) {
		this.journeyType = journeyType;
	}
	public int getNoOfPassengers() {
		return noOfPassengers;
	}
	public void setNoOfPassengers(int noOfPassengers) {
		this.noOfPassengers = noOfPassengers;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Date getTravelStartDate() {
		return travelStartDate;
	}
	public void setTravelStartDate(Date travelStartDate) {
		this.travelStartDate = travelStartDate;
	}
	public String getBookingStatus() {
		return bookingStatus;
	}
	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}


	@Override
	public String toString() {
		return "BookingResponse [BookingId=" + BookingId + ", source=" + source + ", destination=" + destination
				+ ", journeyType=" + journeyType + ", noOfPassengers=" + noOfPassengers + ", amount=" + amount
				+ ", travelStartDate=" + travelStartDate + ", bookingStatus=" + bookingStatus + "]";
	}
	
	
}
