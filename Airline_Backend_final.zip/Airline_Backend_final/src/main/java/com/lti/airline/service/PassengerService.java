package com.lti.airline.service;

public interface PassengerService {

}
