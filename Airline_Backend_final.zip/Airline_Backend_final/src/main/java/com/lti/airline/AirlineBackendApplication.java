package com.lti.airline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirlineBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirlineBackendApplication.class, args);
		System.out.println("spring boot app started");
	}

}
