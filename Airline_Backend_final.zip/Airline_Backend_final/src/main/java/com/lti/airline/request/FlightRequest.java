package com.lti.airline.request;

import java.sql.Date;

import com.lti.airline.enums.ClassType;
import com.lti.airline.enums.JourneyType;

public class FlightRequest {

	private String journeyType;
	private String source;
	private String destination;
	private Date travelDate;
	private int noOfPassengers;
	private String classType;

	public FlightRequest() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FlightRequest(String journeyType, String source, String destination, Date travelDate, int noOfPassengers,
			String classType) {
		super();
		this.journeyType = journeyType;
		this.source = source;
		this.destination = destination;
		this.travelDate = travelDate;
		this.noOfPassengers = noOfPassengers;
		this.classType = classType;
	}

	public String getJourneyType() {
		return journeyType;
	}

	public void setJourneyType(String journeyType) {
		this.journeyType = journeyType;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Date getTravelDate() {
		return travelDate;
	}

	public void setTravelDate(Date travelDate) {
		this.travelDate = travelDate;
	}

	public int getNoOfPassengers() {
		return noOfPassengers;
	}

	public void setNoOfPassengers(int noOfPassengers) {
		this.noOfPassengers = noOfPassengers;
	}

	public String getClassType() {
		return classType;
	}

	public void setClassType(String classType) {
		this.classType = classType;
	}

	@Override
	public String toString() {
		return "FlightRequest [journeyType=" + journeyType + ", source=" + source + ", destination=" + destination
				+ ", travelDate=" + travelDate + ", noOfPassengers=" + noOfPassengers + ", classType=" + classType
				+ "]";
	}

	
	
}
