package com.lti.airline.repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lti.airline.model.FlightCustomer;

@Repository
public class FlightCustomerRepoImpl extends BaseRepo implements FlightCustomerRepo{

	@Override
	public boolean registerUser(FlightCustomer flightCustomer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Transactional
	public FlightCustomer getUserDetails(long userId) {
		
		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery("select f from FlightCustomer f where f.userId =:userId");
		query.setParameter("userId",userId);
		FlightCustomer user = (FlightCustomer) query.getSingleResult();
		return user;
	}
	
	
	@Override
	@Transactional
	public long registerFlightCustomer(FlightCustomer cus) {
		EntityManager entityManager = getEntityManager();
		Query query = entityManager
				.createQuery("select c from FlightCustomer c where c.emailId=:emailId or c.phoneNumber=:phoneNumber");
		query.setParameter("emailId", cus.getEmailId());
		query.setParameter("phoneNumber", cus.getPhoneNumber());

		FlightCustomer flc = null;
		try {
			flc = (FlightCustomer) query.getSingleResult();
			System.out.println(flc);
			if (flc == null) {
				return entityManager.merge(cus).getUserId();
			} else {
				System.out.println("Customer Id: " + flc.getUserId());
			}
		} catch (NoResultException e) {
			return entityManager.merge(cus).getUserId();
		} catch (Exception e) {
			e.printStackTrace();
			return 0l;
		}
		return 0l;

	}

	@Override
	@Transactional
	public long loginFlightCustomer(FlightCustomer logcus) {
		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery("select c from FlightCustomer c where c.emailId=:emailId");
		System.out.println("\n\n\n" + logcus);
		query.setParameter("emailId", logcus.getEmailId());
		FlightCustomer flc = null;
		try {
			flc = (FlightCustomer) query.getSingleResult();
			System.out.println(flc);
			if (flc == null) {
				return 0;

			} else if (flc.getPassword().equals(logcus.getPassword())) {
				System.out.println("Login successful");
				System.out.println(flc.getUserId());
				return flc.getUserId();
				
			} else {
				return 0;
			}
		} catch (NoResultException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

}
