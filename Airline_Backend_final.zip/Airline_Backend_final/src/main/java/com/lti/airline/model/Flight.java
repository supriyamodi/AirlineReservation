package com.lti.airline.model;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the FLIGHT database table.
 * 
 */
@Entity
@NamedQuery(name="Flight.findAll", query="SELECT f FROM Flight f")
public class Flight implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="FLIGHT_ID")
	private long flightId;

	@Column(name="ARRIVAL_TIME")
	private Time arrivalTime;

	@Column(name="DEPARTURE_TIME")
	private Time departureTime;

	private String destination;

	@Column(name="DESTINATION_TERMINAL")
	private String destinationTerminal;

	private float fare;

	@Column(name="FLIGHT_NAME")
	private String flightName;

	@Column(name="FLIGHT_STATUS")
	private String flightStatus;

	private String source;

	@Column(name="SOURCE_TERMINAL")
	private String sourceTerminal;

	@Column(name="TOTAL_SEATS")
	private int totalSeats;

	//bi-directional many-to-one association to Booking
	@OneToMany(mappedBy="flight", fetch=FetchType.LAZY)
	private Set<Booking> bookings;

	public Flight() {
	}

	public Flight( Time arrivalTime, Time departureTime, String destination,
			String destinationTerminal, float fare, String flightName, String flightStatus, String source,
			String sourceTerminal, int totalSeats) {
		super();
		this.arrivalTime = arrivalTime;
		this.departureTime = departureTime;
		this.destination = destination;
		this.destinationTerminal = destinationTerminal;
		this.fare = fare;
		this.flightName = flightName;
		this.flightStatus = flightStatus;
		this.source = source;
		this.sourceTerminal = sourceTerminal;
		this.totalSeats = totalSeats;
	}
	
	public long getFlightId() {
		return this.flightId;
	}

	public void setFlightId(long flightId) {
		this.flightId = flightId;
	}

	public Time getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(Time arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public Time getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(Time departureTime) {
		this.departureTime = departureTime;
	}

	public String getDestination() {
		return this.destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getDestinationTerminal() {
		return this.destinationTerminal;
	}

	public void setDestinationTerminal(String destinationTerminal) {
		this.destinationTerminal = destinationTerminal;
	}

	public float getFare() {
		return this.fare;
	}

	public void setFare(float fare) {
		this.fare = fare;
	}

	public String getFlightName() {
		return this.flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public String getFlightStatus() {
		return this.flightStatus;
	}

	public void setFlightStatus(String flightStatus) {
		this.flightStatus = flightStatus;
	}

	public String getSource() {
		return this.source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getSourceTerminal() {
		return this.sourceTerminal;
	}

	public void setSourceTerminal(String sourceTerminal) {
		this.sourceTerminal = sourceTerminal;
	}

	public int getTotalSeats() {
		return this.totalSeats;
	}

	public void setTotalSeats(int totalSeats) {
		this.totalSeats = totalSeats;
	}

	@JsonIgnore
	public Set<Booking> getBookings() {
		return this.bookings;
	}

	public void setBookings(Set<Booking> bookings) {
		this.bookings = bookings;
	}

	public Booking addBooking(Booking booking) {
		getBookings().add(booking);
		booking.setFlight(this);

		return booking;
	}

	public Booking removeBooking(Booking booking) {
		getBookings().remove(booking);
		booking.setFlight(null);

		return booking;
	}

}