package com.lti.airline.service;

public class PassengerServiceImpl implements PassengerService {

}
