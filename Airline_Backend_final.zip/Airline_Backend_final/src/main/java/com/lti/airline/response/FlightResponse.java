package com.lti.airline.response;

import java.sql.Timestamp;

public class FlightResponse {
	
	private int flightId;
	private String flightName;
	private Timestamp departureTime;
	private Timestamp arrivalTime;
	private String sourceTerminal;
	private String destinationTerminal;
	private Timestamp duration;
	
	
	public FlightResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public FlightResponse(int flightId, String flightName, Timestamp departureTime, Timestamp arrivalTime,
			String sourceTerminal, String destinationTerminal, Timestamp duration) {
		super();
		this.flightId = flightId;
		this.flightName = flightName;
		this.departureTime = departureTime;
		this.arrivalTime = arrivalTime;
		this.sourceTerminal = sourceTerminal;
		this.destinationTerminal = destinationTerminal;
		this.duration = duration;
	}


	public int getFlightId() {
		return flightId;
	}
	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public Timestamp getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(Timestamp departureTime) {
		this.departureTime = departureTime;
	}
	public Timestamp getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(Timestamp arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	public String getSourceTerminal() {
		return sourceTerminal;
	}
	public void setSourceTerminal(String sourceTerminal) {
		this.sourceTerminal = sourceTerminal;
	}
	public String getDestinationTerminal() {
		return destinationTerminal;
	}
	public void setDestinationTerminal(String destinationTerminal) {
		this.destinationTerminal = destinationTerminal;
	}
	public Timestamp getDuration() {
		return duration;
	}
	public void setDuration(Timestamp duration) {
		this.duration = duration;
	}
	
	
	
	

}
