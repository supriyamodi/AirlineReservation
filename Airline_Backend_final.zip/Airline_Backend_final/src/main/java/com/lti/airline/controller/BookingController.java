package com.lti.airline.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.lti.airline.model.Booking;
import com.lti.airline.response.BookingResponse;
import com.lti.airline.service.BookingService;

@CrossOrigin(origins="*")
@RestController 
@RequestMapping("/bookings")
public class BookingController {


	@Autowired
	BookingService bookingService;
	
	
	public Set<Booking> getAllBookings(){
		
		bookingService.getAllBookingService();
		return null;
		
	}
	
	@GetMapping
	@RequestMapping(value= "/demo")
	@ResponseBody
	public String demo() {
		return "successful";
	}
	
	@GetMapping(value = "/getBooking/{bookingId}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Booking getBooking(@PathVariable long bookingId) {
		
		Booking booking = bookingService.getBookingService(bookingId);
		
		return booking;
	}
	
	@GetMapping(value = "/cancelBooking/{bookingId}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean cancelTicket(@PathVariable long bookingId) {
		
		boolean status = bookingService.cancelBookingService(bookingId);
	
		return status;
	}
	
	@GetMapping(value = "/getUserBookings/{userId}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<BookingResponse> getUserBooking(@PathVariable long userId) {
		
		List<BookingResponse> bookingList = bookingService.getUserBookingService(userId);
	
		return bookingList;
	}
	
}
