package com.lti.airline.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.airline.model.FlightCustomer;
import com.lti.airline.repository.FlightCustomerRepo;

@Service
public class FlightCustomerServiceImpl implements FlightCustomerService {
	
	@Autowired
	FlightCustomerRepo flightCustomerRepo;

	@Override
	public boolean userLoginService() {
		
		return false;
	}

	@Override
	public boolean userRegisterService(FlightCustomer request) {
		
		FlightCustomer flightCustomer = new FlightCustomer();
		flightCustomer.setFirstName(request.getFirstName());
		flightCustomer.setLastName(request.getLastName());
		flightCustomer.setDateOfBirth(request.getDateOfBirth());
		flightCustomer.setEmailId(request.getEmailId());
		flightCustomer.setPhoneNumber(request.getPhoneNumber());
		
		boolean status = flightCustomerRepo.registerUser(flightCustomer);
		return false;
		
	}
	
	@Override
	public long registerFlightCustomer(FlightCustomer cus) {
		return flightCustomerRepo.registerFlightCustomer(cus);
	}
	@Override
	public long loginFlightCustomer(FlightCustomer logcus) {
		
		return flightCustomerRepo.loginFlightCustomer(logcus);
	}
	
	public FlightCustomer getUserDetailsService(long userId) {
		FlightCustomer flightCust = flightCustomerRepo.getUserDetails(userId);
		return flightCust;
		}
	

}
