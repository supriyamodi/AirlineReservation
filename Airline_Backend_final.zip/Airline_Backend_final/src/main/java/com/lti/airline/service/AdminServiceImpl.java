package com.lti.airline.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.airline.model.Admin;
import com.lti.airline.model.Flight;
import com.lti.airline.repository.AdminRepoImpl;
import com.lti.airline.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService {
	
	@Autowired
	AdminRepoImpl admRepoImpl;
	
	@Override
	public boolean loginAdminService(Admin admin) {
		System.out.println("Admin Service Layer Visited-Login Service.");
		 return admRepoImpl.loginAdmin(admin);
	}	
	
	@Override
	public void addFlightService(Flight newFlight) {
		System.out.println("Admin Service Layer Visited-Add Service.");
		admRepoImpl.addFlight(newFlight);
	}

	@Override
	public void deleteFlightService(long flightId) {
		
		System.out.println("Admin Service Layer Visited-Delete Service.");
		admRepoImpl.deleteFlight(flightId);
		
		
	}

}
