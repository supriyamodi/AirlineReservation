package com.lti.airline.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.lti.airline.model.Flight;
import com.lti.airline.model.Seat;
import com.lti.airline.request.FlightRequest;
import com.lti.airline.request.PaymentRequest;
import com.lti.airline.request.SeatStatusRequest;
import com.lti.airline.request.SelectFlightRequest;
import com.lti.airline.request.SelectSeatRequest;
import com.lti.airline.response.FlightResponse;
import com.lti.airline.service.FlightService;
import com.lti.airline.service.PaymentService;
import com.lti.airline.service.SeatService;


@CrossOrigin(origins="*")
@RestController 
@RequestMapping("/flights")
public class FlightController {

	@Autowired
	private FlightService flightService;
	
	@Autowired
	private SeatService seatService;
	
	@Autowired
	private PaymentService paymentService;

	@PostMapping(value = "/search", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<Flight> findFlight(@RequestBody FlightRequest flightRequest) {
//	public List<Flight> findFlight() {
		
		List<Flight> flightList = new ArrayList<Flight>();
		flightList = flightService.getAvailableFlightsService(flightRequest);
		return flightList;
	}
	
	
	@GetMapping(value = "/getAllFlights", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<Flight> getAllFlights() {
		
		List<Flight> flightList = new ArrayList<Flight>();
		flightList = flightService.getAllFlightsService();
		return flightList;
	}
	
	@PostMapping(value = "/selectFlight", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public long selectFlight(@RequestBody SelectFlightRequest request) {
		
		
		long bookingId = flightService.selectFlightService(request);
		return bookingId;
	}
	
	@PostMapping(value = "/selectSeat", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean selectSeat(@RequestBody SelectSeatRequest[] request) {
		
		for (SelectSeatRequest selectSeatRequest : request) {
			boolean status = seatService.selectSeatService(selectSeatRequest);
//			if(status == true) {
//				return "Seat Booked";
//			}else {
//				return "Seat Not Booked";
//			}
		}
		return true;
	}
	
	@PostMapping(value = "/getSeatStatus", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<Seat.SeatKey> getSeatStatus(@RequestBody SeatStatusRequest request) {
		
		List<Seat.SeatKey> seatList = seatService.getSeatStatusService(request);
		return seatList;
	}
	
	@PostMapping(value = "/makePayment", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean setPaymentStatus(@RequestBody PaymentRequest request) {
		
		boolean status = paymentService.insertPaymentService(request);
	
		return status;
	}
	
	
}
