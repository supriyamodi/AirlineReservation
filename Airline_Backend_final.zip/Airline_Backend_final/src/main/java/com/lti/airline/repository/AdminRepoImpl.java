package com.lti.airline.repository;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lti.airline.model.Admin;
import com.lti.airline.model.Flight;
import com.lti.airline.repository.AdminRepo;

@Repository
public class AdminRepoImpl implements AdminRepo {

	@Autowired
	EntityManager entityManager;

	@Transactional
	public boolean loginAdmin (Admin adminAccount) {
		Query query = entityManager.createQuery("select a from Admin a where a.adminEmail=:adminEmail");
		System.out.println("\n\n\n" + adminAccount);
		query.setParameter("adminEmail", adminAccount.getAdminEmail());
		Admin adm = null;
		try {
			adm = (Admin) query.getSingleResult();
			System.out.println(adm);
			if (adm == null) {
				return false;

			} else if (adm.getPassword().equals(adminAccount.getPassword())) {
				System.out.println("Admin Login Successful");
				return true;
			} else {
				return false;
			}
		} catch (NoResultException e) {
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	@Transactional
	public void addFlight(Flight newFlight) {
		entityManager.persist(newFlight);
		System.out.println("Flight Added Successfully.");

	}

	@Transactional
	public void deleteFlight(long flightId) {

		String status = "Inactive";
		
		Flight flight = entityManager.find(Flight.class, flightId);

		long fId = flight.getFlightId();
		
		Query query = entityManager
				.createQuery("update Flight f set f.flightStatus=:Inactive where f.flightId=:fId");

		query.setParameter("fId", fId);
		query.setParameter("Inactive", status);
		query.executeUpdate();

		System.out.println("Flight Deleted Successfully.");

	}

	@Override
	public List<Flight> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Flight> findAll(Sort sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Flight> findAllById(Iterable<Long> ids) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Flight> List<S> saveAll(Iterable<S> entities) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void flush() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public <S extends Flight> S saveAndFlush(S entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Flight> List<S> saveAllAndFlush(Iterable<S> entities) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteAllInBatch(Iterable<Flight> entities) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAllByIdInBatch(Iterable<Long> ids) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAllInBatch() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Flight getOne(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Flight getById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Flight> List<S> findAll(Example<S> example) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Flight> List<S> findAll(Example<S> example, Sort sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Page<Flight> findAll(Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Flight> S save(S entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Flight> findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean existsById(Long id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void deleteById(Long id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Flight entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAllById(Iterable<? extends Long> ids) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll(Iterable<? extends Flight> entities) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public <S extends Flight> Optional<S> findOne(Example<S> example) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Flight> Page<S> findAll(Example<S> example, Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Flight> long count(Example<S> example) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public <S extends Flight> boolean exists(Example<S> example) {
		// TODO Auto-generated method stub
		return false;
	}

}
