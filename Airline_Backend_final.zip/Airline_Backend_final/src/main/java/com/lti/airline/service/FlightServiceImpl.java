package com.lti.airline.service;


import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.airline.model.Booking;
import com.lti.airline.model.Flight;
import com.lti.airline.model.FlightCustomer;
import com.lti.airline.repository.BookingRepo;
import com.lti.airline.repository.FlightCustomerRepo;
import com.lti.airline.repository.FlightRepo;
import com.lti.airline.request.FlightRequest;
import com.lti.airline.request.SelectFlightRequest;
import com.lti.airline.response.FlightResponse;

import javassist.expr.NewArray;

@Service
public class FlightServiceImpl implements FlightService {
	
	@Autowired
	FlightRepo flightRepo;

	@Autowired
	BookingRepo bookingRepo;
	
	@Autowired
	FlightCustomerRepo flightCustomerRepo;
//	
	@Override
	public List<Flight> getAvailableFlightsService(FlightRequest request) {
		
		ArrayList<String> seatList = new ArrayList<String>();
//		public void addSeats() {
			seatList.add("1A");
			seatList.add("1B");
			seatList.add("1C");
			seatList.add("1D");
			seatList.add("1E");
			seatList.add("1F");
			
			seatList.add("2A");
			seatList.add("2B");
			seatList.add("2C");
			seatList.add("2D");
			seatList.add("2E");
			seatList.add("2F");
			
			seatList.add("3A");
			seatList.add("3B");
			seatList.add("3C");
			seatList.add("3D");
			seatList.add("3E");
			seatList.add("3F");
			
			seatList.add("4A");
			seatList.add("4B");
			seatList.add("4C");
			seatList.add("4D");
			seatList.add("4E");
			seatList.add("4F");
			
			seatList.add("5A");
			seatList.add("5B");
			seatList.add("5C");
			seatList.add("5D");
			seatList.add("5E");
			seatList.add("5F");
			
			seatList.add("6A");
			seatList.add("6B");
			seatList.add("6C");
			seatList.add("6D");
			seatList.add("6E");
			seatList.add("6F");
			
			seatList.add("7A");
			seatList.add("7B");
			seatList.add("7C");
			seatList.add("7D");
			seatList.add("7E");
			seatList.add("7F");
			
			seatList.add("8A");
			seatList.add("8B");
			seatList.add("8C");
			seatList.add("8D");
			seatList.add("8E");
			seatList.add("8F");
			
			seatList.add("9A");
			seatList.add("9B");
			seatList.add("9C");
			seatList.add("9D");
			seatList.add("9E");
			seatList.add("9F");
		
			seatList.add("10A");
			seatList.add("10B");
			seatList.add("10C");
			seatList.add("10D");
			seatList.add("10E");
			seatList.add("10F");
		
//		}
//		for (String string : seatList) {
//			System.out.println("SeatNo"+string);
//		}
		
		List<Flight> flightList = new ArrayList<Flight>();
		
		ArrayList<Long> totalFlightIds = (ArrayList<Long>) flightRepo.getFlightIdsUsingSrcAndDest(request.getSource(), request.getDestination());
		
//		Date date = Date.valueOf(LocalDate.now());
//		Date date = Date.valueOf("2021-05-13");
		Date date = request.getTravelDate();
		int noOfPassengers=request.getNoOfPassengers();
		for(Long fId : totalFlightIds) {
			System.out.println("fId: "+fId);
			ArrayList<Long> getBookingIds = flightRepo.getBookingIdsOnparticularDateForSpecificFlight(fId,date);
			long bookedSeatCount=0;
			
			for(Long bId: getBookingIds) {
				System.out.println("bId: "+bId);
				for (String seatNo : seatList) {
					System.out.println("seatNo+bId"+seatNo+" "+bId);
					bookedSeatCount += flightRepo.getSeatCountForEachBookingId(seatNo,(long)bId);
//					bookedSeatCount += flightRepo.getSeatCountForEachBookingId("3D",(long)510);
//					System.out.println("Booked Seat Count:"+ bookedSeatCount);
				}
			}
//			System.out.println("Booked Seat Count:"+ bookedSeatCount);
			if((60-bookedSeatCount)<noOfPassengers) {
				totalFlightIds.remove(fId);
			}
		}
		
		for(Long fId : totalFlightIds) {
//			System.out.println("Final Flight Id:"+fId);
			Flight eachFlightDetails = flightRepo.getFlightDetailsByFlightId(fId);	
			flightList.add(eachFlightDetails);
		}
		
		return flightList;
	}
	
	//For testing
//	@Override
//	public List<Flight> getAvailableFlightsService() {
//		List<Flight> flightList = new ArrayList<Flight>();
//		
//		ArrayList<Long> totalFlightIds = (ArrayList<Long>) flightRepo.getFlightIdsUsingSrcAndDest("Mumbai", "Chennai");
//		
////		Date date = Date.valueOf(LocalDate.now());
//		Date date = Date.valueOf("2021-05-13");
//		int noOfPassengers=2;
//		for(Long fId : totalFlightIds) {
//			System.out.println("fId: "+fId);
//			ArrayList<Long> getBookingIds = flightRepo.getBookingIdsOnparticularDateForSpecificFlight(fId,date);
//			int bookedSeatCount=0;
//			
//			for(Long bId: getBookingIds) {
//				for (String seatNo : seatList) {
//					bookedSeatCount += flightRepo.getSeatCountForEachBookingId(seatNo,bId);
//				}
//			}
//			System.out.println("BookingCount"+bookedSeatCount);
//			if((60-bookedSeatCount)<noOfPassengers) {
//				totalFlightIds.remove(fId);
//			}
//		}
//		
//		for(Long fId : totalFlightIds) {
//			Flight eachFlightDetails = flightRepo.getFlightDetailsByFlightId(fId);	
//			flightList.add(eachFlightDetails);
//		}
//
//		return flightList;
//	}

	@Override
	public List<Flight> getAllFlightsService() {
		
		List<Flight> flightList = new ArrayList<Flight>();
		flightList  = flightRepo.getAllFlight();
		return flightList;
	}

	@Override
	public long selectFlightService(SelectFlightRequest request) {
		
		long flightId = request.getFlightId();
		Flight flight = flightRepo.getFlightDetailsByFlightId(flightId);
		Time arrivalTime = flight.getArrivalTime();
		Time departureTime  = flight.getDepartureTime();
//		Date duration= (Date)(arrivalTime-departureTime);
		long userId = request.getUserId();
		FlightCustomer user = flightCustomerRepo.getUserDetails(userId);
		
		Booking booking = new Booking();
		Date date = Date.valueOf(LocalDate.now());
		booking.setBookingDate(date);
		booking.setTravelStartDate(request.getTravelStartDate());
		booking.setFlight(flight);
		booking.setClassType(request.getClassType());
		booking.setJourneyType(request.getJourneyType());
		booking.setNoOfSeatsBookedByUser(request.getNoOfPassengers());
		booking.setFlightCustomer(user);
		booking.setBookingStatus("Payment_Failed");
		long bookingId = bookingRepo.createBooking(booking);
		return bookingId;
	}


	
	
	
}
