package com.lti.airline.model;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.sql.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the CANCELLATION database table.
 * 
 */
@Entity
@Table(name="CANCELLATION")
@NamedQuery(name="Cancellation.findAll", query="SELECT c FROM Cancellation c")
public class Cancellation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CANCELLATION_DATE")
	private Date cancellationDate;

	@Column(name="REFUND_AMOUNT")
	private double refundAmount;

	@Column(name="REFUND_STATUS")
	private String refundStatus;

	//bi-directional many-to-one association to Payment
	@ManyToOne
	@JoinColumn(name="PAYMENT_ID")
	private Payment payment;

	public Cancellation() {
	}

	public Date getCancellationDate() {
		return cancellationDate;
	}

	public void setCancellationDate(Date cancellationDate) {
		this.cancellationDate = cancellationDate;
	}

	public double getRefundAmount() {
		return this.refundAmount;
	}

	public void setRefundAmount(double refundAmount) {
		this.refundAmount = refundAmount;
	}

	public String getRefundStatus() {
		return this.refundStatus;
	}

	public void setRefundStatus(String refundStatus) {
		this.refundStatus = refundStatus;
	}

//	@JsonIgnore
//	public Payment getPayment() {
//		return this.payment;
//	}

	public void setPayment(Payment payment) {
		this.payment = payment;
	}

}