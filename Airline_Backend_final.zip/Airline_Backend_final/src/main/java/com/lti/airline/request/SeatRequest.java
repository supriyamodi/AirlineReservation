package com.lti.airline.request;

public class SeatRequest {

	private int bookingId;
	
}
