package com.lti.airline.request;

public class PaymentRequest {
	
	private float amount;
	private long bookingId;
	private String paymentMethod;
	private String paymentStatus;
//	private String seatNo;

	
	
	public PaymentRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public PaymentRequest(float amount, long bookingId, String paymentMethod, String paymentStatus) {
		super();
		this.amount = amount;
		this.bookingId = bookingId;
		this.paymentMethod = paymentMethod;
		this.paymentStatus = paymentStatus;
//		this.seatNo = seatNo;
	}

	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public long getBookingId() {
		return bookingId;
	}
	public void setBookingId(long bookingId) {
		this.bookingId = bookingId;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	@Override
	public String toString() {
		return "PaymentRequest [amount=" + amount + ", bookingId=" + bookingId + ", paymentMethod=" + paymentMethod
				+ ", paymentStatus=" + paymentStatus + "]";
	}
	
	
	

	

	
	
	

}
