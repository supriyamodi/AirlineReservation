package com.lti.airline.request;

import java.sql.Date;

public class SelectFlightRequest {

	private long flightId;
	private long userId;
	private Date travelStartDate;
	private int noOfPassengers;
	private String classType;
	private String journeyType;
	
	
	
	
	public SelectFlightRequest(long flightId, long userId, Date travelStartDate, int noOfPassengers, String classType,
			String journeyType) {
		super();
		this.flightId = flightId;
		this.userId = userId;
		this.travelStartDate = travelStartDate;
		this.noOfPassengers = noOfPassengers;
		this.classType = classType;
		this.journeyType = journeyType;
	}
	public SelectFlightRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	public long getFlightId() {
		return flightId;
	}
	public void setFlightId(long flightId) {
		this.flightId = flightId;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public Date getTravelStartDate() {
		return travelStartDate;
	}
	public void setTravelStartDate(Date travelStartDate) {
		this.travelStartDate = travelStartDate;
	}
	public int getNoOfPassengers() {
		return noOfPassengers;
	}
	public void setNoOfPassengers(int noOfPassengers) {
		this.noOfPassengers = noOfPassengers;
	}
	public String getClassType() {
		return classType;
	}
	public void setClassType(String classType) {
		this.classType = classType;
	}
	public String getJourneyType() {
		return journeyType;
	}
	public void setJourneyType(String journeyType) {
		this.journeyType = journeyType;
	}
	
	
	
}
