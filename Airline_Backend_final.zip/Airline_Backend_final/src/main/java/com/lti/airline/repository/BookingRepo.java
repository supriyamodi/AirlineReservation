package com.lti.airline.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.airline.model.Booking;
import com.lti.airline.request.SeatStatusRequest;
import com.lti.airline.request.SelectFlightRequest;

@Repository
public interface BookingRepo {

	long createBooking(Booking booking);

	Booking getBooking(long bookingId);
	
	List<Long> getBookingIdsForFlightOnTravelDate(SeatStatusRequest request);
	
	void updateBookingStatus(long bookingId, String status);
	
	List<Booking> getBookingByUserId(long userId);
}
