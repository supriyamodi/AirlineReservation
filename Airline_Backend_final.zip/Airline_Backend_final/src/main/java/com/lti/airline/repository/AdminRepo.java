package com.lti.airline.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.lti.airline.model.Admin;
import com.lti.airline.model.Flight;

@Repository
public interface AdminRepo extends JpaRepository<Flight, Long> {
	
	public boolean loginAdmin (Admin adminAccount);
	void addFlight (Flight newFlight);
	void deleteFlight(long flightId);
	

}
