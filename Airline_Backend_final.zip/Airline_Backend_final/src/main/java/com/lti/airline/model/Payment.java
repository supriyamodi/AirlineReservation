package com.lti.airline.model;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Set;


/**
 * The persistent class for the PAYMENT database table.
 * 
 */
@Entity
@NamedQuery(name="Payment.findAll", query="SELECT p FROM Payment p")
public class Payment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="PAYMENT_ID")
	private long paymentId;

	private float amount;

	@Column(name="PAYMENT_METHOD")
	private String paymentMethod;

	@Column(name="PAYMENT_STATUS")
	private String paymentStatus;

	//bi-directional many-to-one association to Cancellation
	@OneToMany(mappedBy="payment", fetch=FetchType.EAGER)
	private Set<Cancellation> cancellations;

	//bi-directional many-to-one association to Booking
	@ManyToOne
	@JoinColumn(name="BOOKING_ID")
	private Booking booking;

	public Payment() {
	}

	public long getPaymentId() {
		return this.paymentId;
	}

	public void setPaymentId(long paymentId) {
		this.paymentId = paymentId;
	}

	public float getAmount() {
		return this.amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public String getPaymentMethod() {
		return this.paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getPaymentStatus() {
		return this.paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

//	@JsonIgnore
//	public Set<Cancellation> getCancellations() {
//		return this.cancellations;
//	}

	public void setCancellations(Set<Cancellation> cancellations) {
		this.cancellations = cancellations;
	}

//	public Cancellation addCancellation(Cancellation cancellation) {
//		getCancellations().add(cancellation);
//		cancellation.setPayment(this);
//
//		return cancellation;
//	}

//	public Cancellation removeCancellation(Cancellation cancellation) {
//		getCancellations().remove(cancellation);
//		cancellation.setPayment(null);
//
//		return cancellation;
//	}

	@JsonIgnore
	public Booking getBooking() {
		return this.booking;
	}

	public void setBooking(Booking booking) {
		this.booking = booking;
	}

}