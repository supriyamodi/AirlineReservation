package com.lti.airline.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.lti.airline.model.Admin;
import com.lti.airline.model.Flight;
import com.lti.airline.service.AdminServiceImpl;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/admin")

public class AdminController {
	
	@Autowired
	AdminServiceImpl admSrvcImpl;

	public AdminController() {
		System.out.println("Admin Controller Constructor It Is.");
		
	}
	

	@ResponseBody
	@PostMapping(path="/loginAdmin")
	
	public boolean loginAdmin(@RequestBody Admin admin) {
		
		System.out.println("Login Admin Method Controller");		
		return admSrvcImpl.loginAdminService(admin);
		
		
	}
	
	@ResponseBody
	@PostMapping(path="/addFlight")
	
	public void addFlight(@RequestBody Flight newFlight) {
		
		System.out.println("Add Flight Method Controller");		
		admSrvcImpl.addFlightService(newFlight);
		
	}
	
	
	@PutMapping
	@ResponseBody
	@RequestMapping(value="/deleteFlight/{flightId}")
	public void deleteFlight(@PathVariable long flightId) {
		
		System.out.println("Delete Flight Method Controller");
		admSrvcImpl.deleteFlightService(flightId);
		
	}
	
}
