package com.lti.airline.enums;

public enum JourneyType {

	One_way,
	Return
}
