package com.lti.airline.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.airline.model.Seat;
import com.lti.airline.model.Seat.SeatKey;

@Repository
public interface SeatRepo {

	Seat getSeat(Seat.SeatKey sk);
	
	List<Seat> getAllSeats(); 
	
	boolean insertSeat(Seat seat);

	boolean getBookedSeatStatus(SeatKey skey);

	void updateSeatStatus(SeatKey skey, String status);
	
	void cancelSeats(long bookingId);
	
	List<Seat.SeatKey> getSeatByBookingId(long bookingId);
}
