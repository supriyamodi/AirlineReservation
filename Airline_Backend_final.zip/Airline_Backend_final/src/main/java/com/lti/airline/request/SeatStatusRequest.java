package com.lti.airline.request;

import java.sql.Date;

public class SeatStatusRequest {

	private Long flightId;
	private Date travelDate;
	
	public SeatStatusRequest(Long flightId, Date travelDate) {
		super();
		this.flightId = flightId;
		this.travelDate = travelDate;
	}
	
	public SeatStatusRequest() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getFlightId() {
		return flightId;
	}
	public void setFlightId(Long flightId) {
		this.flightId = flightId;
	}
	public Date getTravelDate() {
		return travelDate;
	}
	public void setTravelDate(Date travelDate) {
		this.travelDate = travelDate;
	}

	@Override
	public String toString() {
		return "SeatStatusRequest [flightId=" + flightId + ", travelDate=" + travelDate + "]";
	}
	
	
	
}
