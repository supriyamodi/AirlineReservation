package com.lti.airline.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.airline.model.Flight;

@Repository
public interface FlightRepo {

	List<Flight> getAllFlight();

	int getBookingId(Date date);
	
	List<Long> getFlightIdsUsingSrcAndDest(String string, String string2);

	ArrayList<Long> getBookingIdsOnparticularDateForSpecificFlight(Long i, Date date);

	long getSeatCountForEachBookingId(String seatNo, Long bId);

	Flight getFlightDetailsByFlightId(Long fId);

	Flight getFlightByBookingId(long bookingId);
	
}
