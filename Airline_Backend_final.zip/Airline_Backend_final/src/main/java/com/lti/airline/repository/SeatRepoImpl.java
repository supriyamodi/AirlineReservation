package com.lti.airline.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lti.airline.model.Seat;
import com.lti.airline.model.Seat.SeatKey;


@Repository
public class SeatRepoImpl extends BaseRepo implements SeatRepo{

	@Transactional
	public Seat getSeat(Seat.SeatKey sk) {
		Seat s = entityManager.find(Seat.class, sk);
		return s;
	}

	@Transactional
	public List<Seat> getAllSeats() {
		List<Seat> seatList = entityManager.createQuery(" from Seat").getResultList();
		return seatList;
	}

	@Transactional
	public boolean insertSeat(Seat seat) {
		entityManager.persist(seat);
		return true;
	}

	@Transactional
	public boolean getBookedSeatStatus(SeatKey skey) {
		EntityManager entityManager = getEntityManager();
		String status = "Booked";
		Query query = entityManager.createQuery("select s from Seat s where s.seatKey =: skey");
		query.setParameter("skey", skey);
		
		try {
			Seat seat = (Seat) query.getSingleResult();
			String seatStatus = seat.getSeatStatus();
			System.out.println(seatStatus);
			if(seatStatus.equals(status)) {
				return true;
			}else
				return false;
		}catch (Exception e) {
			System.out.println("Seat not found");
		}
		return false;
	}

	@Transactional
	public void updateSeatStatus(SeatKey skey, String status) {
		System.out.println("Into updateSeatStatus...");
		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery("UPDATE Seat s SET s.seatStatus =:status where s.seatKey=:skey");
		query.setParameter("skey", skey);
		query.setParameter("status", status);
		int rows = query.executeUpdate();
		System.out.println(rows+" updated");
		
	}

	@Transactional
	public void cancelSeats(long bookingId) {
		System.out.println("into cancelSeats...");
		ArrayList<String> seatList = new ArrayList<String>();
//		public void addSeats() {
			seatList.add("1A");
			seatList.add("1B");
			seatList.add("1C");
			seatList.add("1D");
			seatList.add("1E");
			seatList.add("1F");
			
			seatList.add("2A");
			seatList.add("2B");
			seatList.add("2C");
			seatList.add("2D");
			seatList.add("2E");
			seatList.add("2F");
			
			seatList.add("3A");
			seatList.add("3B");
			seatList.add("3C");
			seatList.add("3D");
			seatList.add("3E");
			seatList.add("3F");
			
			seatList.add("4A");
			seatList.add("4B");
			seatList.add("4C");
			seatList.add("4D");
			seatList.add("4E");
			seatList.add("4F");
			
			seatList.add("5A");
			seatList.add("5B");
			seatList.add("5C");
			seatList.add("5D");
			seatList.add("5E");
			seatList.add("5F");
			
			seatList.add("6A");
			seatList.add("6B");
			seatList.add("6C");
			seatList.add("6D");
			seatList.add("6E");
			seatList.add("6F");
			
			seatList.add("7A");
			seatList.add("7B");
			seatList.add("7C");
			seatList.add("7D");
			seatList.add("7E");
			seatList.add("7F");
			
			seatList.add("8A");
			seatList.add("8B");
			seatList.add("8C");
			seatList.add("8D");
			seatList.add("8E");
			seatList.add("8F");
			
			seatList.add("9A");
			seatList.add("9B");
			seatList.add("9C");
			seatList.add("9D");
			seatList.add("9E");
			seatList.add("9F");
		
			seatList.add("10A");
			seatList.add("10B");
			seatList.add("10C");
			seatList.add("10D");
			seatList.add("10E");
			seatList.add("10F");
		
			
		for (String seatNo : seatList) {
			System.out.println("SeatNo:"+seatNo);
			Seat.SeatKey skey = new Seat.SeatKey(seatNo, bookingId);
			boolean status = getBookedSeatStatus(skey);
			System.out.println(status);
			if (status) {
				updateSeatStatus(skey,"Available");
			}
		}
		
	}

	@Transactional
	public List<Seat.SeatKey> getSeatByBookingId(long bookingId) {
		List<Seat.SeatKey> list = new ArrayList<Seat.SeatKey>(); 
		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery("select s.seatKey from Seat s where s.seatKey.bookingId=:bId");
		query.setParameter("bId", bookingId);
		list = query.getResultList();
		return list;
	}
	
	
}

