package com.lti.airline.service;

public class CancellationServiceImpl implements CancellationService {

}
