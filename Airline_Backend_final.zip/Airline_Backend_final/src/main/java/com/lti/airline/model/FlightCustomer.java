package com.lti.airline.model;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the FLIGHT_CUSTOMER database table.
 * 
 */
@Entity
@Table(name="FLIGHT_CUSTOMER")
@NamedQuery(name="FlightCustomer.findAll", query="SELECT f FROM FlightCustomer f")
public class FlightCustomer implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="USER_ID")
	private long userId;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_OF_BIRTH")
	private Date dateOfBirth;

	@Column(name="EMAIL_ID")
	private String emailId;

	@Column(name="FIRST_NAME")
	private String firstName;

	private String gender;

	@Column(name="LAST_NAME")
	private String lastName;

	private String password;

	@Column(name="PHONE_NUMBER")
	private String phoneNumber;

	private String title;

	//bi-directional many-to-one association to Booking
	@OneToMany(mappedBy="flightCustomer", fetch=FetchType.EAGER)
	private Set<Booking> bookings;

	//bi-directional many-to-one association to Passenger
	@OneToMany(mappedBy="flightCustomer", fetch=FetchType.EAGER)
	private Set<Passenger> passengers;

	public FlightCustomer() {
	}

	public long getUserId() {
		return this.userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public Date getDateOfBirth() {
		return this.dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmailId() {
		return this.emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhoneNumber() {
		return this.phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

//	@JsonIgnore
//	public Set<Booking> getBookings() {
//		return this.bookings;
//	}

	public void setBookings(Set<Booking> bookings) {
		this.bookings = bookings;
	}

//	public Booking addBooking(Booking booking) {
//		getBookings().add(booking);
//		booking.setFlightCustomer(this);
//
//		return booking;
//	}
//
//	public Booking removeBooking(Booking booking) {
//		getBookings().remove(booking);
//		booking.setFlightCustomer(null);
//
//		return booking;
//	}

//	@JsonIgnore
//	public Set<Passenger> getPassengers() {
//		return this.passengers;
//	}

	public void setPassengers(Set<Passenger> passengers) {
		this.passengers = passengers;
	}

//	public Passenger addPassenger(Passenger passenger) {
//		getPassengers().add(passenger);
//		passenger.setFlightCustomer(this);
//
//		return passenger;
//	}
//
//	public Passenger removePassenger(Passenger passenger) {
//		getPassengers().remove(passenger);
//		passenger.setFlightCustomer(null);
//
//		return passenger;
//	}

}