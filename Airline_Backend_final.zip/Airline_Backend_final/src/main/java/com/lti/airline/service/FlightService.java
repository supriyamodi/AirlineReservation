package com.lti.airline.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lti.airline.model.Flight;
import com.lti.airline.request.FlightRequest;
import com.lti.airline.request.SelectFlightRequest;
import com.lti.airline.response.FlightResponse;

@Service
public interface FlightService {

//	List<Flight> getAvailableFlightsService();

	List<Flight> getAllFlightsService();

	List<Flight> getAvailableFlightsService(FlightRequest flightRequest);

	long selectFlightService(SelectFlightRequest request);

}
