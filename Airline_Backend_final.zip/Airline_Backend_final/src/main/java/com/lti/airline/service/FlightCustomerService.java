package com.lti.airline.service;

import org.springframework.stereotype.Service;

import com.lti.airline.model.FlightCustomer;

@Service
public interface FlightCustomerService {

	boolean userLoginService();

	boolean userRegisterService(FlightCustomer request);
	
	long registerFlightCustomer(FlightCustomer cus);
	long loginFlightCustomer(FlightCustomer logcus);

	FlightCustomer getUserDetailsService(long userId);

}
