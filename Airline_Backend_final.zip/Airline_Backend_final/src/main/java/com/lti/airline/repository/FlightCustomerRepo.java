package com.lti.airline.repository;

import org.springframework.stereotype.Repository;

import com.lti.airline.model.FlightCustomer;

@Repository
public interface FlightCustomerRepo {
//
	boolean registerUser(FlightCustomer flightCustomer);

	FlightCustomer getUserDetails(long userId);



//	List<FlightCustomer> getAllFlightCustomerByEmailANDPassword(String emailId, String password);
      long registerFlightCustomer(FlightCustomer cus);
     long loginFlightCustomer(FlightCustomer logcus);
}