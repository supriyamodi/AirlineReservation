package com.lti.airline.request;

public class SelectSeatRequest {

	private String seatNo;
	private long bookingId;
	
	
	public SelectSeatRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SelectSeatRequest(String seatNo, long bookingId) {
		super();
		this.seatNo = seatNo;
		this.bookingId = bookingId;
	}
	public String getSeatNo() {
		return seatNo;
	}
	public void setSeatNo(String seatNo) {
		this.seatNo = seatNo;
	}
	public long getBookingId() {
		return bookingId;
	}
	public void setBookingId(long bookingId) {
		this.bookingId = bookingId;
	}
	
}
