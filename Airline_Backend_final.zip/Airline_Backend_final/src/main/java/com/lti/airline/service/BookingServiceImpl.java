package com.lti.airline.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.airline.model.Booking;
import com.lti.airline.model.Cancellation;
import com.lti.airline.model.Flight;
import com.lti.airline.model.Payment;
import com.lti.airline.model.Seat;
import com.lti.airline.repository.BookingRepo;
import com.lti.airline.repository.FlightRepo;
import com.lti.airline.repository.PaymentRepo;
import com.lti.airline.repository.SeatRepo;
import com.lti.airline.response.BookingResponse;

@Service
public class BookingServiceImpl implements BookingService {

	@Autowired
	BookingRepo bookingRepo;

	@Autowired
	SeatRepo seatRepo;

	@Autowired
	PaymentRepo paymentRepo;
	
	@Autowired
	FlightRepo flightRepo;

	@Override
	public Set<Booking> getAllBookingService() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Booking getBookingService(long bookingId) {
		Booking booking = bookingRepo.getBooking(bookingId);
		return booking;
	}

	@Override
	public boolean cancelBookingService(long bookingId) {

		List<Seat.SeatKey> skeyList = seatRepo.getSeatByBookingId(bookingId);
		for (Seat.SeatKey seatKey : skeyList) {
			seatRepo.updateSeatStatus(seatKey, "Available");
		}

		bookingRepo.updateBookingStatus(bookingId, "Cancelled");

		Payment payment = paymentRepo.getSuccessfulPaymentByBookingId(bookingId);

		double refundAmount = 0.9 * payment.getAmount();
		Cancellation cancel = new Cancellation();
		Date date = Date.valueOf(LocalDate.now());
		cancel.setCancellationDate(date);
		cancel.setPayment(payment);
		cancel.setRefundStatus("Refunded");
		cancel.setRefundAmount(refundAmount);
		boolean status = paymentRepo.insertIntoCancellation(cancel);
		return status;
	}

	@Override
	public List<BookingResponse> getUserBookingService(long userId) {
		List<BookingResponse> bookings = new ArrayList<BookingResponse>();
		List<Booking> userBooking = bookingRepo.getBookingByUserId(userId);
		for (Booking booking : userBooking) {
			Flight flightDetails = flightRepo.getFlightByBookingId(booking.getBookingId());

			BookingResponse br= new BookingResponse();
			br.setBookingId(booking.getBookingId());
			br.setJourneyType(booking.getJourneyType());
			br.setNoOfPassengers(booking.getNoOfSeatsBookedByUser());
			br.setTravelStartDate(booking.getTravelStartDate());
			br.setAmount(flightDetails.getFare() * booking.getNoOfSeatsBookedByUser());
			br.setSource(flightDetails.getSource());
			br.setDestination(flightDetails.getDestination());
			br.setBookingStatus(booking.getBookingStatus());
			bookings.add(br);	
		}
		return bookings;
	}
}
