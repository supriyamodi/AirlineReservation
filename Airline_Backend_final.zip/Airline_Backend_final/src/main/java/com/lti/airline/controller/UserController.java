//package com.lti.airline.controller;
//
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.lti.airline.model.FlightCustomer;
//import com.lti.airline.service.FlightCustomerService;
//
//@CrossOrigin(origins="*")
//@RestController 
//@RequestMapping("/user")
//public class UserController {
//
//	FlightCustomerService flightCustomerService;
//	
//	@RequestMapping("/login")
//	public boolean userLogin() {
//		boolean status=flightCustomerService.userLoginService();
//		return status;
//	}
//	
//	@RequestMapping("/register")
//	public boolean registerUser(@RequestBody FlightCustomer request) {
//		boolean status=flightCustomerService.userRegisterService(request);
//		return true;
//	}
//}
