export class FlightRequest{
    journeyType:string="";
	source:string="";
	destination:string="";
	travelDate:Date | undefined;
	noOfPassengers:number=null;
	classType:string="";
}

// {
//     "journeyType":"One_way",
//     "source":"Mumbai",
//     "destination":"Chennai",
//     "travelDate":"2021-05-13",
//     "noOfPassengers":"2",
//     "classType":"Economy"
// }