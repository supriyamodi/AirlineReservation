import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Flight } from '../flight';
import { SearchFlightService } from '../search-flight.service';
import { FlightRequest } from './FlightRequest';
import {formatDate} from '@angular/common';


@Component({
  selector: 'app-search-flight',
  templateUrl: './search-flight.component.html',
  styleUrls: ['./search-flight.component.css']
})
export class SearchFlightComponent implements OnInit {


  flightRequest : FlightRequest =new FlightRequest();
  availableFlights: Flight[]=[];
  currentDate: string= formatDate(new Date(), 'yyyy-MM-dd', 'en');
  adult:number;
  children:number;
  isLoggedIn:number;
  logg:boolean = false;
  constructor(private searchFlightService: SearchFlightService, private router:Router) { 
    
  }

  ngOnInit(): void {
    // this.isLoggedIn=parseInt(sessionStorage.getItem('isLoggedIn'));
    // if(this.isLoggedIn===1){
    //   this.logg=true;
    //   console.log(this.logg);
    // }
    console.log(this.currentDate);
  }

  onclick(){
    console.log("button clicked")
  }
  searchFlight(){
    this.flightRequest.noOfPassengers=parseInt(this.adult.toString())+parseInt(this.children.toString());
    console.log("in search flight");
    // console.log(sessionStorage.getItem('userId'));
    console.log(JSON.stringify(this.flightRequest));
    localStorage.setItem('flightRequest', JSON.stringify(this.flightRequest));
    this.searchFlightService.getAvailableFlights(this.flightRequest).subscribe(
      (data)=>{
        console.log(data);
        this.availableFlights = data;

        localStorage.setItem('availableFlights', JSON.stringify(this.availableFlights));
        this.router.navigate(['/select-flight']);
        
      }
    );
    // this.router.navigate(['/select-flight']);
  }
}


