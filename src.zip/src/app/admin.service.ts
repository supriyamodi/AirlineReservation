import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Admin } from './admin-login/Admin';
import { Flight } from './flight';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  baseURL: string='http://localhost:8087/admin';
  constructor ( private myhttp: HttpClient ) { }

  public addFlightService(flight:Flight) {
    return this.myhttp.post("http://localhost:8085/admin/addFlight",flight);
  }

   public deleteFlightService ( flightId : any ): Observable <any> {
    console.log("Deletion in Process" + flightId); 
  return this.myhttp.get<any>("http://localhost:8085/admin/deleteFlight/"+flightId);
  }

   public loginAdmin(admLogin:Admin):Observable<boolean>{
    console.log("Calling Service"); 
    return this.myhttp.post<boolean>("http://localhost:8085/admin/loginAdmin",admLogin);  
   }
  }
