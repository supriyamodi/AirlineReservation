import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SearchFlightService } from '../search-flight.service';
import { Booking } from './Booking';
import { UserProfile } from './UserProfile';

@Component({
  selector: 'app-userdashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.scss']
})
export class UserdashboardComponent implements OnInit {



div0:boolean=true;
div1:boolean=true;
div2:boolean=true;
div3:boolean=false;
div4:boolean=false;
div5:boolean=false
div6:boolean=false;
div7:boolean=false;
div8:boolean=false;
div9:boolean=false;
div10:boolean=false;
div11:boolean=false;
div12:boolean=false;
div13:boolean=false;
div14:boolean=false;
div15:boolean=false;
div16:boolean=false;
div17:boolean=false;
div18:boolean=false;
div19:boolean=false;
div20:boolean=false;
div21:boolean=false;
div22:boolean=false;

cancelledBookings :Booking[]=[];
confirmedBookings :Booking[]=[];
failedBookings :Booking[]=[];

userId:number = parseInt(sessionStorage.getItem('userId'));
// userId:number =5;
userProfile : UserProfile;
  constructor(private searchFlightService: SearchFlightService, private router: Router) {} 


  ngOnInit(): void {
    this.searchFlightService.getUserProfile(this.userId).subscribe(
      (data)=>{
        this.userProfile=data;
        console.log(JSON.stringify(this.userProfile));
      }
    );

    this.searchFlightService.findAllUserBookingsService(this.userId).subscribe(
      (data)=>{
        // this.tempBookings=data;
        // console.log(JSON.stringify(this.tempBookings));
        for(let i=0; i<data.length;i++){
          if(data[i].bookingStatus.localeCompare("Cancelled")==0){
            this.cancelledBookings.push(data[i]);
          } else if(data[i].bookingStatus.localeCompare("Confirmed")==0){
            this.confirmedBookings.push(data[i]);
          } else if(data[i].bookingStatus.localeCompare("Payment_Failed")==0){
            this.failedBookings.push(data[i]);
          } 
        }
      }
    );
  }

  cancelBooking(bId:Booking){

      var index = this.confirmedBookings.indexOf(bId);
      console.log(bId.bookingId);
      this.searchFlightService.cancelBooking(bId.bookingId).subscribe(
        data=>{
            if(data){ 
              this.confirmedBookings.splice(index,1);
              bId.bookingStatus="Cancelled";
              this.cancelledBookings.push(bId);
            }
        }
      );
    
  }



  div1Function(){
    this.div0=false;
    this.div1=true;
    this.div2=true;
    this.div3=false;
    this.div4=false;
    this.div5=false;
    this.div6=false;
    this.div7=false;
    this.div8=false;
    this.div9=false;
    this.div10=false;
    this.div11=false;
    this.div12=false;
    this.div13=false;
    this.div14=false;
    this.div15=false;
    this.div16=false;
    this.div17=false;
    this.div18=false;
    this.div19=false;
    this.div20=false;
    this.div21=false;
    // this.searchFlightService.getUserProfile(this.userId).subscribe(
    //   (data)=>{
    //     this.userProfile=data;
    //     console.log(JSON.stringify(this.userProfile));
    //   }
    // );
  }

  // No div2Function

  div3Function(){
    this.div0=false;
    this.div1=true;
    this.div2=false;
    this.div3=true;
    this.div4=false;
    this.div5=false;
    this.div6=false;
    this.div7=false;
    this.div8=false;
    this.div9=false;
    this.div10=false;
    this.div11=false;
    this.div12=false;
    this.div13=false;
    this.div14=false;
    this.div15=false;
    this.div16=false;
    this.div17=false;
    this.div18=false;
    this.div19=false;
    this.div20=false;
    this.div21=false;
  }

  div4Function(){
    this.div0=false;
    this.div1=true;
    this.div2=false;
    this.div3=false;
    this.div4=true;
    this.div5=false;
    this.div6=false;
    this.div7=false;
    this.div8=false;
    this.div9=false;
    this.div10=false;
    this.div11=false;
    this.div12=false;
    this.div13=false;
    this.div14=false;
    this.div15=false;
    this.div16=false;
    this.div17=false;
    this.div18=false;
    this.div19=false;
    this.div20=false;
    this.div21=false;
  }


  div5Function(){
    this.div0=false;
    this.div1=false;
    this.div2=false;
    this.div3=false;
    this.div4=false;
    this.div5=true;
    this.div6=false;
    this.div7=false;
    this.div8=false;
    this.div9=false;
    this.div10=false;
    this.div11=false;
    this.div12=false;
    this.div13=false;
    this.div14=false;
    this.div15=false;
    this.div16=false;
    this.div17=false;
    this.div18=false;
    this.div19=false;
    this.div20=true;
    this.div21=false;
    
  }


  div6Function(){
    this.div0=false;
    this.div1=false;
    this.div2=false;
    this.div3=false;
    this.div4=false;
    this.div5=false;
    this.div6=true;
    this.div7=false;
    this.div8=false;
    this.div9=false;
    this.div10=false;
    this.div11=false;
    this.div12=false;
    this.div13=false;
    this.div14=false;
    this.div15=false;
    this.div16=false;
    this.div17=false;
    this.div18=false;
    this.div19=false;
    this.div20=false;
    this.div21=false;
  }
  div7Function(){
    this.div0=true;
    this.div1=false;
    this.div2=false;
    this.div3=false;
    this.div4=false;
    this.div5=false;
    this.div6=false;
    this.div7=true;
    this.div8=false;
    this.div9=false;
    this.div10=false;
    this.div11=false;
    this.div12=false;
    this.div13=false;
    this.div14=false;
    this.div15=false;
    this.div16=false;
    this.div17=false;
    this.div18=false;
    this.div19=false;
    this.div20=false;
    this.div21=false;
  }
  div8Function(){
    this.div0=false;
    this.div1=false;
    this.div2=false;
    this.div3=false;
    this.div4=false;
    this.div5=false;
    this.div6=false;
    this.div7=true;
    this.div8=true;
    this.div9=false;
    this.div10=false;
    this.div11=false;
    this.div12=false;
    this.div13=false;
    this.div14=false;
    this.div15=false;
    this.div16=false;
    this.div17=false;
    this.div18=false;
    this.div19=false;
    this.div20=false;
    this.div21=false;
  }

  div9Function(){
    this.div0=false;
    this.div1=false;
    this.div2=false;
    this.div3=false;
    this.div4=false;
    this.div5=false;
    this.div6=false;
    this.div7=true;
    this.div8=false;
    this.div9=true;
    this.div10=false;
    this.div11=false;
    this.div12=false;
    this.div13=false;
    this.div14=false;
    this.div15=false;
    this.div16=false;
    this.div17=false;
    this.div18=false;
    this.div19=false;
    this.div20=false;
    this.div21=false;
  }
  div10Function(){
    this.div0=false;
    this.div1=false;
    this.div2=false;
    this.div3=false;
    this.div4=false;
    this.div5=false;
    this.div6=false;
    this.div7=true;
    this.div8=true;
    this.div9=false;
    this.div10=true;
    this.div11=false;
    this.div12=false;
    this.div13=false;
    this.div14=false;
    this.div15=true;
    this.div16=false;
    this.div17=false;
    this.div18=false;
    this.div19=false;
    this.div20=false;
    this.div21=false;
  }

  div11Function(){
    this.div0=false;
    this.div1=false;
    this.div2=false;
    this.div3=false;
    this.div4=false;
    this.div5=false;
    this.div6=false;
    this.div7=true;
    this.div8=true;
    this.div9=false;
    this.div10=false;
    this.div11=true;
    this.div12=false;
    this.div13=false;
    this.div14=false;
    this.div15=false;
    this.div16=false;
    this.div17=false;
    this.div18=false;
    this.div19=false;
    this.div20=false;
    this.div21=false;
  }
  div12Function(){
    this.div0=false;
    this.div1=false;
    this.div2=false;
    this.div3=false;
    this.div4=false;
    this.div5=false;
    this.div6=false;
    this.div7=true;
    this.div8=false;
    this.div9=true;
    this.div10=false;
    this.div11=false;
    this.div12=true;
    this.div13=false;
    this.div14=false;
    this.div15=true;
    this.div16=false;
    this.div17=false;
    this.div18=false;
    this.div19=false;
    this.div20=false;
    this.div21=false;
  }
  div13Function(){
    this.div0=false;
    this.div1=false;
    this.div2=false;
    this.div3=false;
    this.div4=false;
    this.div5=false;
    this.div6=false;
    this.div7=true;
    this.div8=false;
    this.div9=true;
    this.div10=false;
    this.div11=false;
    this.div12=false;
    this.div13=true;
    this.div14=false;
    this.div15=true;
    this.div16=false;
    this.div17=false;
    this.div18=false;
    this.div19=false;
    this.div20=false;
    this.div21=false;
  }
  div14Function(){
    this.div0=false;
    this.div1=false;
    this.div2=false;
    this.div3=false;
    this.div4=false;
    this.div5=false;
    this.div6=false;
    this.div7=true;
    this.div8=true;
    this.div9=false;
    this.div10=false;
    this.div11=false;
    this.div12=false;
    this.div13=false;
    this.div14=true;
    this.div15=true;
    this.div16=false;
    this.div17=false;
    this.div18=false;
    this.div19=false;
    this.div20=false;
    this.div21=false;
  }
//No div15 function
div16Function(){
  this.div0=false;
  this.div1=false;
  this.div2=false;
  this.div3=false;
  this.div4=false;
  this.div5=true;
  this.div6=false;
  this.div7=false;
  this.div8=false;
  this.div9=false;
  this.div10=false;
  this.div11=false;
  this.div12=false;
  this.div13=false;
  this.div14=false;
  this.div15=false;
  this.div16=true;
  this.div17=false;
  this.div18=false;
  this.div19=false;
  this.div20=false;
  this.div21=false;
}
div17Function(){
  this.div0=false;
  this.div1=false;
  this.div2=false;
  this.div3=false;
  this.div4=false;
  this.div5=true;
  this.div6=false;
  this.div7=false;
  this.div8=false;
  this.div9=false;
  this.div10=false;
  this.div11=false;
  this.div12=false;
  this.div13=false;
  this.div14=false;
  this.div15=false;
  this.div16=false;
  this.div17=true;
  this.div18=false;
  this.div19=false;
  this.div20=false;
  this.div21=false;
}
div18Function(){
  this.div0=false;
  this.div1=false;
  this.div2=false;
  this.div3=false;
  this.div4=false;
  this.div5=true;
  this.div6=false;
  this.div7=false;
  this.div8=false;
  this.div9=false;
  this.div10=false;
  this.div11=false;
  this.div12=false;
  this.div13=false;
  this.div14=false;
  this.div15=false;
  this.div16=false;
  this.div17=false;
  this.div18=true;
  this.div19=false;
  this.div20=false;
  this.div21=false;
}
div19Function(){
  this.div0=false;
  this.div1=false;
  this.div2=false;
  this.div3=false;
  this.div4=false;
  this.div5=true;
  this.div6=false;
  this.div7=false;
  this.div8=false;
  this.div9=false;
  this.div10=false;
  this.div11=false;
  this.div12=false;
  this.div13=false;
  this.div14=false;
  this.div15=false;
  this.div16=false;
  this.div17=false;
  this.div18=false;
  this.div19=true;
  this.div20=false;
  this.div21=false;
 
}

div21Function(){
  this.div0=false;
  this.div1=false;
  this.div2=false;
  this.div3=false;
  this.div4=false;
  this.div5=false;
  this.div6=false;
  this.div7=false;
  this.div8=false;
  this.div9=false;
  this.div10=false;
  this.div11=false;
  this.div12=false;
  this.div13=false;
  this.div14=false;
  this.div15=false;
  this.div16=false;
  this.div17=false;
  this.div18=false;
  this.div19=false;
  this.div20=false;
  this.div21=true;
  this.div22=false;
  this.router.navigate(['/logout']);

}

div22Function(){
  this.div0=false;
  this.div1=false;
  this.div2=false;
  this.div3=false;
  this.div4=false;
  this.div5=false;
  this.div6=false;
  this.div7=false;
  this.div8=false;
  this.div9=false;
  this.div10=false;
  this.div11=false;
  this.div12=false;
  this.div13=false;
  this.div14=false;
  this.div15=false;
  this.div16=false;
  this.div17=false;
  this.div18=false;
  this.div19=false;
  this.div20=false;
  this.div21=false;
  this.div22=true;
  this.router.navigate(['/search-flight'])

}

}