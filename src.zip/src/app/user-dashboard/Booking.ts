export class Booking{
    source: string;
    destination: string;
    journeyType: string;
    noOfPassengers: number;
    amount: number;
    travelStartDate: Date;
    bookingId: number;
    bookingStatus: string;
}