export class UserProfile{
    userId: number;
    dateOfBirth: string;
    emailId:string;
    firstName:string;
    lastName:string;
    phoneNumber:string;
    title:string;
    gender:string;
    password:string;
}