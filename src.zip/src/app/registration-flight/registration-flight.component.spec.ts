import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationFlightComponent } from './registration-flight.component';

describe('RegistrationFlightComponent', () => {
  let component: RegistrationFlightComponent;
  let fixture: ComponentFixture<RegistrationFlightComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegistrationFlightComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationFlightComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
