import { JsonpClientBackend } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FlightCustomerService } from '../flight-customer.service';
import { FlightCustomer } from './FlightCustomer';

@Component({
  selector: 'app-registration-flight',
  templateUrl: './registration-flight.component.html',
  styleUrls: ['./registration-flight.component.css']
})
export class RegistrationFlightComponent implements OnInit {
  constructor(private flserve: FlightCustomerService) { }
flc1=new FlightCustomer();
isRegistered:boolean=false;
ngOnInit(): void {
  
}; //invocation of th subscribe method
public registerFlightCustomer(){
  console.log(JSON.stringify(this.flc1));
  this.flserve.registerFlightCustomer(this.flc1).subscribe(
    (data )=>
    {
     console.log((data));
     if(data===0){
       this.isRegistered=true;
     }
    },
    (err)=>{
      console.log(err);
    }
  )
  }


}