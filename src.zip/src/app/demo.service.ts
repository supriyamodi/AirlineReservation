import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DemoService {

  baseUrl:string = "http://localhost:8087/";
  constructor(private myhttp:HttpClient) { }

  getDemoService():Observable<string>{
    return this.myhttp.get<string>(this.baseUrl+"bookings/demo/");
  }
}

