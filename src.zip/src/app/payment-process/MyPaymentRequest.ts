export class MyPaymentRequest{
    amount:number;
	bookingId:number;
	paymentMethod:string;
	paymentStatus:string;
}