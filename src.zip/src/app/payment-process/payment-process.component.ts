import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SearchFlightService } from '../search-flight.service';
import { SelectFlightRequest } from '../select-flight/SelectFlightRequest';
import { MyPaymentRequest } from './MyPaymentRequest';

@Component({
  selector: 'app-payment-process',
  templateUrl: './payment-process.component.html',
  styleUrls: ['./payment-process.component.css']
})
export class PaymentProcessComponent implements OnInit {
  card:boolean=false;
  upi:boolean=false;
  netbanking:boolean=false;
  googlepay:boolean=false;
  phonepe:boolean=false;
  payment: MyPaymentRequest= new MyPaymentRequest();

  constructor(private searchFlightService: SearchFlightService, private router:Router) { }

  ngOnInit(): void {
  }

  toggleCard(){

    if(this.card==false && this.upi==true && this.netbanking==false){
      this.upi=!this.upi;
      this.card=!this.card;
    }
    else if(this.card==false && this.upi==false && this.netbanking==true){
      this.netbanking=!this.netbanking;
      this.card=!this.card;
    }
    else{
      this.card=!this.card;
    }

    
  }
  toggleUpi(){
    if(this.upi==false && this.card==true && this.netbanking==false){
      this.card=!this.card;
      this.upi=!this.upi;
    }
    else if(this.upi==false && this.card==false && this.netbanking==true){
      this.netbanking=!this.netbanking;
      this.upi=!this.upi;
    }
    else{
      this.upi=!this.upi;
    }
  }
  toggleNetbanking(){
    if(this.netbanking==false && this.card==true && this.upi==false){
      this.card=!this.card;
      this.netbanking=!this.netbanking;
    }
    else if(this.netbanking==false && this.card==false && this.upi==true){
      this.upi=!this.upi;
      this.netbanking=!this.netbanking;
    }
    else{
      this.netbanking=!this.netbanking;
    }  
  }

  toggleGooglePay(){
    if(this.upi==true){
      if(this.googlepay==false && this.phonepe==true){
        this.phonepe=!this.phonepe;
        this.googlepay=!this.googlepay;        
      }
      else if(this.googlepay==false && this.phonepe==false){
        this.googlepay=!this.googlepay;        
      }
    }
  }

  togglePhonePe(){
    if(this.upi==true){
      if(this.phonepe==false && this.googlepay==true){
        this.googlepay=!this.googlepay;        
        this.phonepe=!this.phonepe;
      }
      else if(this.phonepe==false && this.googlepay==false){
        this.phonepe=!this.phonepe;
      }
    }
  }

  makePayment(status:string){
    this.payment.paymentStatus=status;
    this.payment.amount=parseInt(sessionStorage.getItem('amount'));
    this.payment.bookingId = parseInt(sessionStorage.getItem('bookingId'));
    this.payment.paymentMethod="Card";
    console.log(JSON.stringify(this.payment));
    this.searchFlightService.makePayment(this.payment).subscribe(
      (data)=>{
        console.log(data);
        this.router.navigate(['/dashboard']);
      }
      );
  }
  

}