import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AdminService } from '../admin.service';
import { Flight } from '../flight';

@Component({
  selector: 'app-admin-functions',
  templateUrl: './admin-functions.component.html',
  styleUrls: ['./admin-functions.component.css']
})
export class AdminFunctionsComponent implements OnInit {

  delete:boolean=false;
  add: boolean = false;

  // delete: Flight;
  allFlight: Flight[] = [] ; 
  tempFlight: Flight[] =[] ;
  flightId: any ;
  flight: Flight = new Flight();

  constructor(private admService: AdminService) { }

  ngOnInit(): void {
  }

  deleteFunc(){
    console.log(this.delete);

    if(this.delete==false && this.add ==false){
      this.delete=!this.delete;
    }
    else if(this.delete==false && this.add ==true){

        this.add=!this.add;
        this.delete=!this.delete;
    }
    else if(this.delete==true){
      this.delete=!this.delete
    }


    console.log(this.delete);

  }
  
  addFunc(){
    console.log(this.add);

    if(this.delete==false && this.add ==false){
      this.add=!this.add;
    }
    else if(this.delete==true && this.add ==false){
        this.delete=!this.delete;
        this.add=!this.add;
    }  
    else if(this.add==true){
      this.add=!this.add
    }  
    console.log(this.add);  
  }

  xdata: any;
  deleted: Boolean;
  addFlight(regForm:NgForm) 
  {
    
    console.log('Flight to Add '+this.flight);
    this.admService.addFlightService(this.flight).
    subscribe((data:any) =>
    {
       this.xdata = data;
      console.log('log is' + data);
       // if(data == null ) {
          this.deleted=true;
         // alert('record has been deleted');
          this.tempFlight= this.allFlight;

          console.log('from addFlight()'); 

    });
  
  }


  deleteFlight() 
  {
    
    console.log('FlightId to delete '+this.flightId);
    this.admService.deleteFlightService(this.flightId).
    subscribe((data:any) =>
    {
       this.xdata = data;
      console.log('log is' + data);
       // if(data == null ) {
          this.deleted=true;
         // alert('record has been deleted');
          this.tempFlight= this.allFlight.filter(e=>(e.flightId != this.flightId));

          console.log('from deleteFlight()'); 

    });
  }

}
