import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentSupportedComponent } from './payment-supported.component';

describe('PaymentSupportedComponent', () => {
  let component: PaymentSupportedComponent;
  let fixture: ComponentFixture<PaymentSupportedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaymentSupportedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentSupportedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
