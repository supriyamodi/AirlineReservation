import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-payment-supported',
  templateUrl: './payment-supported.component.html',
  styleUrls: ['./payment-supported.component.css']
})
export class PaymentSupportedComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  continue(){
    this.router.navigate(['/make-payment']);
  }

}
