export class SelectFlightRequest{
    
    flightId:number;
	userId:number | undefined;
	travelStartDate:Date|undefined;
	noOfPassengers:number;
	classType:string;
	journeyType:string;
}