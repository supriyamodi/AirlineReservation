import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Flight } from '../flight';
import { SearchFlightService } from '../search-flight.service';
import { FlightRequest } from '../search-flight/FlightRequest';
import { SelectFlightRequest } from './SelectFlightRequest';

@Component({
  selector: 'app-select-flight',
  templateUrl: './select-flight.component.html',
  styleUrls: ['./select-flight.component.css']
})
export class SelectFlightComponent implements OnInit {

  allFlights:Flight[]=[];
  flightReq: FlightRequest;
  selectFlightReq = new SelectFlightRequest();
  // this.flightreq= JSON.parse(localStorage.getItem('flightRequest'));
  oneway:boolean=true;
  twoway:boolean=false;
  amount:number;
  
  constructor(private searchFlightService: SearchFlightService, private router:Router) { }

  ngOnInit(): void {
    this.allFlights=JSON.parse(localStorage.getItem('availableFlights'));
    this.flightReq= JSON.parse(localStorage.getItem('flightRequest'));
    console.log("Is Logged in"+sessionStorage.getItem('isLoggedIn'));
    if(sessionStorage.getItem('isLoggedIn')===null){
      
      sessionStorage.setItem('isLoggedIn',"0");
      console.log("Is Logged in after setting"+sessionStorage.getItem('isLoggedIn'));
    }
  }
  
  // toggle(){
  //   this.oneway=!this.oneway;
  //   this.twoway=!this.twoway;
  // }
  toggle(){
    this.oneway=!this.oneway;
    this.twoway=!this.twoway;
  }

  selectFlight(f:Flight){

    
    console.log("in select flight:"+f);

    this.amount=f.fare*this.flightReq.noOfPassengers;
    sessionStorage.setItem('amount',this.amount.toString());

    this.selectFlightReq.flightId= f.flightId;
    this.selectFlightReq.classType= this.flightReq.classType;
    this.selectFlightReq.journeyType = this.flightReq.journeyType;
    this.selectFlightReq.noOfPassengers= this.flightReq.noOfPassengers;
    this.selectFlightReq.travelStartDate = this.flightReq.travelDate;
    // this.selectFlightReq.userId = 1;
    // console.log(JSON.stringify(this.selectFlightReq));
    localStorage.setItem('selectedFlight', JSON.stringify(this.selectFlightReq));
    
    if(parseInt(sessionStorage.getItem('isLoggedIn'))===0){
      console.log("redirecting to user login");
      sessionStorage.setItem('fromSelectFlight',"1");
      this.router.navigate(['/userLoginPage']);
      
    }else{
      console.log("redirecting to select seat");
      this.router.navigate(['/select-seat']);
    }
    
    // this.searchFlightService.selectFlights(this.selectFlightReq).subscribe(
    //   (data)=>{
    //     sessionStorage.setItem('bookingId',data.toString());
    //     console.log(sessionStorage.getItem('bookingId'));
        
        
    //   }
    // );
    
  }

}
  