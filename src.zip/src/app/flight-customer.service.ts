import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { FlightCustomer } from './registration-flight/FlightCustomer';

@Injectable({
  providedIn: 'root'
})
export class FlightCustomerService {

  baseURL: string = 'http://localhost:8087/registration/' //Spring's EmployeeJPAController 
  
  constructor(private myhttp: HttpClient) { }
  public registerFlightCustomer(flightcustomer:FlightCustomer):Observable<Object>{
    console.log("Calling service"); 
    return this.myhttp.post<Object>('http://localhost:8087/registration/userRegister',flightcustomer);
   }
   public loginFlightCustomer(flightcustomer:FlightCustomer):Observable<any>{
    console.log("Calling service"); 
    return this.myhttp.post<any>('http://localhost:8087/registration/userLogin',flightcustomer);
   }
   
   

}