import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginFlightComponent } from './login-flight.component';

describe('LoginFlightComponent', () => {
  let component: LoginFlightComponent;
  let fixture: ComponentFixture<LoginFlightComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginFlightComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginFlightComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
