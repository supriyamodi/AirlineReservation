import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FlightCustomerService } from '../flight-customer.service';
import { FlightCustomer } from '../registration-flight/FlightCustomer';

@Component({
  selector: 'app-login-flight',
  templateUrl: './login-flight.component.html',
  styleUrls: ['./login-flight.component.css','./style1.css']
})
export class LoginFlightComponent implements OnInit {
 
    constructor(private flserve: FlightCustomerService,private router:Router) { }
  flc2=new FlightCustomer();
  validCredential:boolean=true;
  userId:number;
  ngOnInit(): void {
    // if(sessionStorage.getItem('fromSelectFlight')!=null &&  parseInt(sessionStorage.getItem('fromSelectFlight'))==1 ){
    //   this.router.navigate(['/select-seat']);
    // }else if(parseInt(sessionStorage.getItem('isLoggedIn'))==1){
    //   this.router.navigate(['/dashboard']);
    // }
  }; //invocation of th subscribe method
  public loginFlightCustomer(){
    console.log(JSON.stringify(this.flc2));
    this.flserve.loginFlightCustomer(this.flc2).subscribe(
      (data)=>
      {
       console.log("login console:"+data);
       this.userId=data;
       if(this.userId===0){
        console.log("in login if ");
        this.validCredential=false;
        sessionStorage.setItem('isLoggedIn',"0");
        this.router.navigate(['/userLoginPage']);
        
      }else{
        console.log("in login's else redirecting to seat select");
        sessionStorage.setItem('userId',this.userId+"");
        sessionStorage.setItem('isLoggedIn',"1");
        if(sessionStorage.getItem('fromSelectFlight')!=null &&  parseInt(sessionStorage.getItem('fromSelectFlight'))==1 ){
          this.router.navigate(['/select-seat']);
        }
        else{
          sessionStorage.setItem('fromSelectFlight',"0");
          this.router.navigate(['/dashboard']);
        }
        this.validCredential=true;
      }
       
      },
      (err)=>{
        console.log(err);
      }
    )
    // if(this.userId===0){
    //   console.log("in login if ");
    //   this.validCredential=false;
    //   sessionStorage.setItem('isLoggedIn',"0");
    //   this.router.navigate(['/userLoginPage']);
      
    // }else{
    //   console.log("in login's else redirecting to seat select");
    //   sessionStorage.setItem('userId',this.userId+"");
    //   sessionStorage.setItem('isLoggedIn',"1");
    //   this.router.navigate(['/select-seat']);
    //   this.validCredential=true;
    // }
  
  }
  




}