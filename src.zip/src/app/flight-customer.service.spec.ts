import { TestBed } from '@angular/core/testing';

import { FlightCustomerService } from './flight-customer.service';

describe('FlightCustomerService', () => {
  let service: FlightCustomerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FlightCustomerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
