import { TestBed } from '@angular/core/testing';

import { SearchFlightServiceService } from './search-flight.service';

describe('SearchFlightServiceService', () => {
  let service: SearchFlightServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SearchFlightServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
