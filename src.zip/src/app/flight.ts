import { Time } from "@angular/common";

export class Flight{
    
	flightId:number=0;
    arrivalTime:Time | undefined;	
	departureTime:Time | undefined;
	destination:string="";	
	destinationTerminal:string="";
	fare:number=0;	
	flightName:string="";
	flightStatus:string="";
    source:string="";
	sourceTerminal:string="";
	totalSeats:number=60;

}

//         "flightId": 107,
//         "arrivalTime": "2021-08-09T23:30:00.000+00:00",
//         "departureTime": "2021-08-09T22:30:00.000+00:00",
//         "destination": "Chennai",
//         "destinationTerminal": "T2",
//         "fare": 5000.0,
//         "flightName": "RiseFly",
//         "flightStatus": "Active",
//         "source": "Mumbai",
//         "sourceTerminal": "T9",
//         "totalSeats": 60