import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SearchFlightService } from '../search-flight.service';
import { SelectFlightRequest } from '../select-flight/SelectFlightRequest';
import { SeatKey } from './SeatKey';
import { SeatStatusRequest } from './SeatStatusRequest';

@Component({
  selector: 'app-seat-select',
  templateUrl: './seat-select.component.html',
  styleUrls: ['./seat-select.component.css']
})
export class SeatSelectComponent implements OnInit {

  bookedSeatKeys: SeatKey[]=[];
  newBookingSeats: string[]=[];
  array: SeatKey[]=[];
  seatStatusRequest = new SeatStatusRequest();
  selectedFight = new SelectFlightRequest();
  element :HTMLElement;
  flag:boolean=false;
  isDisabled:boolean=false;
  noOfPassengers:number = JSON.parse(localStorage.getItem('selectedFlight')).noOfPassengers;
  constructor(private searchFlightService: SearchFlightService, private router:Router) { }

  ngOnInit(): void {

    this.selectedFight= JSON.parse(localStorage.getItem('selectedFlight'));
    this.selectedFight.userId=parseInt(sessionStorage.getItem('userId'));
    console.log(JSON.stringify(this.selectedFight));
    this.searchFlightService.selectFlights(this.selectedFight).subscribe(
      (data)=>{
        sessionStorage.setItem('bookingId',data.toString());
        console.log(sessionStorage.getItem('bookingId'));
      }
    );
    
    this.seatStatusRequest.flightId = this.selectedFight.flightId;
    this.seatStatusRequest.travelDate = this.selectedFight.travelStartDate;
    this.searchFlightService.getSeatStatus(this.seatStatusRequest).subscribe(
      (data)=>{
        this.bookedSeatKeys=data;
        console.log(JSON.stringify(this.bookedSeatKeys));
        for (let index = 0; index < this.bookedSeatKeys.length; index++) {
          var id = this.bookedSeatKeys[index].seatNo;
          // console.log(id);
          (<HTMLInputElement> document.getElementById(this.bookedSeatKeys[index].seatNo)).disabled = true;
          }
      }

      
    );
    
    }
    

    selectSeat(seatNo:string){
      
      console.log("Nop"+this.noOfPassengers);
      console.log(seatNo);
      
        if(this.newBookingSeats.includes(seatNo,0)){
          let i = this.newBookingSeats.indexOf(seatNo);
          this.newBookingSeats.splice(i,1);
          this.noOfPassengers++;
          this.isDisabled=false;
        }
        else{
          if(this.noOfPassengers===0){
            // document.getElementById(seatNo).style.background="blue";
          }else{
            this.newBookingSeats.push(seatNo);
            this.noOfPassengers--;
          }
        }
        
        console.log("Printing array"+JSON.stringify(this.newBookingSeats));
    }


    confirmSeats(){
      for (let index = 0; index < this.newBookingSeats.length; index++) {
       
        let seat = new SeatKey();
        seat.seatNo=this.newBookingSeats[index];
        seat.bookingId = parseInt(sessionStorage.getItem('bookingId'));
        this.array.push(seat);

      }
      console.log("array"+JSON.stringify(this.array));

      this.searchFlightService.bookSeats(this.array).subscribe(
        (data)=>{
          console.log(data);
        }
      );
      this.router.navigate(['/supported-payment']);
    }
  }

  // var i = this.cartItems.indexOf(product);
  //   this.cartItems.splice(i,1);
  //   console.log("Cart length  after deletion= "+this.cartItems.length);