export class SeatStatusRequest{
    flightId:number;
	travelDate:Date;
}