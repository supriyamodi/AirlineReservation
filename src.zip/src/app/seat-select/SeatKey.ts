export class SeatKey{
    seatNo:string;
    bookingId:number;
}

