export class SelectSeatRequest{
    seatNo:string;
	bookingId:number;
}