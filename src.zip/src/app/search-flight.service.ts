import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Flight } from './flight';
import { MyPaymentRequest } from './payment-process/MyPaymentRequest';
import { FlightCustomer } from './registration-flight/FlightCustomer';
import { FlightRequest } from './search-flight/FlightRequest';
import { SeatKey } from './seat-select/SeatKey';
import { SeatStatusRequest } from './seat-select/SeatStatusRequest';
import { SelectFlightRequest } from './select-flight/SelectFlightRequest';
import { Booking } from './user-dashboard/Booking';
import { UserProfile } from './user-dashboard/UserProfile';

@Injectable({
  providedIn: 'root'
})

export class SearchFlightService {

  baseUrl:string = "http://localhost:8087/";
  constructor(private myhttp:HttpClient) { }

  getAvailableFlights(flightRequest:FlightRequest):Observable<Flight[]>{
    return this.myhttp.post<Flight[]>(this.baseUrl+"flights/search/",flightRequest);
  }

  selectFlights(selectFlightReq: SelectFlightRequest):Observable<number>{
    return this.myhttp.post<number>(this.baseUrl+"flights/selectFlight/",selectFlightReq);
  }

  getSeatStatus(seatStatusRequest: SeatStatusRequest):Observable<SeatKey[]>{
    return this.myhttp.post<SeatKey[]>(this.baseUrl+"flights/getSeatStatus/",seatStatusRequest);
  }

  bookSeats(seatKey:SeatKey[]):Observable<boolean>{
    return this.myhttp.post<boolean>(this.baseUrl+"flights/selectSeat",seatKey);
  }

  makePayment(payment:MyPaymentRequest):Observable<boolean>{
    return this.myhttp.post<boolean>(this.baseUrl+"flights/makePayment",payment);
  }

  findAllUserBookingsService(userId : number) : Observable<Booking[]> {
    return this.myhttp.get<Booking[]>(this.baseUrl+"bookings/getUserBookings/"+userId);
  }

  getUserProfile(userId:number):Observable<UserProfile>{
    // console.log("in service"+userId);
    return this.myhttp.get<UserProfile>(this.baseUrl+"registration/userDetails/"+userId);
  }

  cancelBooking(bId:number):Observable<any>{
    return this.myhttp.get<any>(this.baseUrl+"bookings/cancelBooking/"+bId);
  }
}
// http://localhost:8087/flights/search

// /getSeatStatus