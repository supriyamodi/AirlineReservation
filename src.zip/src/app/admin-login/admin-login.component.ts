import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';
import { Admin } from './Admin';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css','style1.css']
})

export class AdminLoginComponent implements OnInit {

  constructor(private flserve: AdminService,private router: Router) { }
  admin=new Admin();
  validCredential:boolean=true;
  ngOnInit(): void {
    
  }; //invocation of th subscribe method
  public loginAdmin(){
    console.log(JSON.stringify(this.admin));
    this.flserve.loginAdmin(this.admin).subscribe(
      (data )=>
      {
       console.log(data);
       this.validCredential=data;
      },
      (err)=>{
        console.log(err);
      }

    )
    
    this.router.navigate(['/admin-function']);

  
  }

}
