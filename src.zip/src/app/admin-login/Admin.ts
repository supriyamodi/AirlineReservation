export class Admin{

    adminUserName: string;
    adminEmail: string;
    password: string;
}