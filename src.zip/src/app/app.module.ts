import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SearchFlightComponent } from './search-flight/search-flight.component';
import { LoginFlightComponent } from './login-flight/login-flight.component';
import { RegistrationFlightComponent } from './registration-flight/registration-flight.component';
import { SelectFlightComponent } from './select-flight/select-flight.component';
import { SeatSelectComponent } from './seat-select/seat-select.component';
import { PaymentProcessComponent } from './payment-process/payment-process.component';
import { PaymentSupportedComponent } from './payment-supported/payment-supported.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http'; 
import { DemoService } from './demo.service';
import { UserdashboardComponent } from './user-dashboard/user-dashboard.component';
import { AdminFunctionsComponent } from './admin-functions/admin-functions.component';
import { LogoutComponent } from './logout/logout.component';

@NgModule({
  declarations: [
    AppComponent,
    SearchFlightComponent,
    LoginFlightComponent,
    RegistrationFlightComponent,
    SelectFlightComponent,
    SeatSelectComponent,
    PaymentProcessComponent,
    PaymentSupportedComponent,
    AdminLoginComponent,
    AdminFunctionsComponent,
    UserdashboardComponent,
    LogoutComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
