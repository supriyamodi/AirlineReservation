import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminFunctionsComponent } from './admin-functions/admin-functions.component';
import { AdminLoginComponent} from './admin-login/admin-login.component';
import { LoginFlightComponent } from './login-flight/login-flight.component';
import { LogoutComponent } from './logout/logout.component';
import { PaymentProcessComponent } from './payment-process/payment-process.component';
import { PaymentSupportedComponent } from './payment-supported/payment-supported.component';
import { RegistrationFlightComponent } from './registration-flight/registration-flight.component';
import { SearchFlightComponent } from './search-flight/search-flight.component';
import { SeatSelectComponent } from './seat-select/seat-select.component';
import { SelectFlightComponent } from './select-flight/select-flight.component';
import { UserdashboardComponent } from './user-dashboard/user-dashboard.component';
// import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';



const routes: Routes = [

  {
    //    path:'',
    //  component:HomeComponent
        path:'', redirectTo:'search-flight',pathMatch:'full'
    },
    {
      path:'select-flight',component:SelectFlightComponent
    },
    {
      path:'registerPage',component:RegistrationFlightComponent,
     
    },
    {
      path:'userLoginPage',component:LoginFlightComponent
    },
    {
      path:'adminLoginPage',component:AdminLoginComponent
    },
    {
      path:'admin-function',component:AdminFunctionsComponent
    },
    {
      path:'select-seat',component:SeatSelectComponent
    },
    {
      path:'supported-payment',component:PaymentSupportedComponent
    },
    {
      path:'make-payment',component:PaymentProcessComponent
    },
    {
      path:'dashboard',component:UserdashboardComponent
    },
    {
      path:'search-flight',component:SearchFlightComponent,
    },
    {
      path:'logout',component:LogoutComponent,
    }
   
  ];

@NgModule({
  imports: [[RouterModule.forRoot(routes)]],
  exports: [RouterModule]
})
export class AppRoutingModule { }
